=== RHR WooCommerce Product Filter ===
Contributors: rubelhasanrokib
Tags: woocommerce, product filter, ajax filter, elementor, mobile filter
Version: 2.0.1
Stable tag: 2.0.1
Requires at least: 6.0
Requires PHP: 7.4
Tested up to: 6.8
Requires Plugins: woocommerce
License: GPLv2 or later

Premium, responsive WooCommerce product filter that works with the real WooCommerce / Elementor Pro archive query.

== Description ==
* Filters the existing Archive Products / Loop Grid widget (no second product grid).
* AJAX results — only the product grid refreshes, no page reload (automatic fallback to reload).
* Live product search with image, price, SKU matching and "See all results".
* Hierarchical categories with sub-category tree and "Show more".
* Any WooCommerce attribute (Size, Color…) as chips, checkboxes or color swatches.
* Dual price slider (correct for variable products), in-stock, on-sale and rating filters.
* Active filter chips, reset all, collapsible sections.
* Mobile: smooth drawer from right / left / bottom, "Show results" button, Filter button placed above the product grid next to "Sort by". No auto-open/flash on page load.
* Native Elementor widget "RHR Product Filter" with Style tab (colors, typography, spacing).
* Dashboard: one-click color palettes, every color editable, live preview, labels in any language.

== Installation ==
1. Plugins → Add New → Upload the ZIP → Activate (replaces the old version; settings are kept).
2. RHR Filter (left admin menu) → choose colors, filters and mobile style.
3. Elementor Pro → Theme Builder → Product Archive: drag "RHR Product Filter" into the sidebar container, Archive Products in the main container.
   Or use the shortcode [rhr_product_filter] anywhere.

== Changelog ==
= 2.0.1 =
* NEW: Tablets use the phone layout (Filter button + drawer) — on by default, tablet breakpoint 1024px.
* Elementor editor: the Filter button only shows in tablet/mobile preview, not on desktop.
= 2.0.0 =
* FIX: Mobile filter panel no longer slides in from the left and disappears on category pages (CSS now loads in <head>, drawer is hidden until tapped, transitions enabled after first paint, removed the 5-second DOM polling).
* FIX: Search bar works — no page reload on every keystroke, suggestions no longer blocked by cached nonces, Enter / arrow button applies the search, SKU search added.
* FIX: Standalone shortcode grid used wrong field names (search/categories/price never applied).
* FIX: Price filter now correct for variable products (uses WooCommerce lookup table).
* FIX: Filtering from /page/2/ no longer lands on an empty page (pagination reset).
* FIX: "Auto display on shop pages" setting now actually works.
* FIX: Mobile breakpoint setting is now used by the CSS too.
* NEW: AJAX archive results + AJAX pagination & sorting, Elementor widget, attributes & color swatches, category tree, active chips, rating radios, drawer side option (right / left / bottom), floating button option, one-click palettes, 13 color controls, live preview, reset to defaults, all labels editable.
= 1.7.3 =
* Mobile Filter button mounted outside Elementor containers.
