<?php
/**
 * Dashboard: RHR Filter settings page.
 */
if (!defined('ABSPATH')) exit;

class RHR_WPF_Admin {

    const SLUG = 'rhr-wpf';

    public static function init() {
        add_action('admin_menu', array(__CLASS__, 'menu'));
        add_action('admin_init', array(__CLASS__, 'register'));
        add_action('admin_enqueue_scripts', array(__CLASS__, 'assets'));
        add_action('admin_post_rhr_wpf_reset', array(__CLASS__, 'reset'));
        add_filter('plugin_action_links_' . plugin_basename(RHR_WPF_FILE), array(__CLASS__, 'links'));
    }

    public static function url($tab = '') {
        return admin_url('admin.php?page=' . self::SLUG . ($tab ? '&tab=' . $tab : ''));
    }

    public static function links($links) {
        array_unshift($links, '<a href="' . esc_url(self::url()) . '">' . esc_html__('Settings', 'rhr-woocommerce-product-filter') . '</a>');
        return $links;
    }

    public static function menu() {
        add_menu_page('RHR Product Filter', 'RHR Filter', 'manage_options', self::SLUG, array(__CLASS__, 'page'), 'dashicons-filter', 56);
    }

    public static function register() {
        register_setting('rhr_wpf_group', 'rhr_wpf_settings', array('sanitize_callback' => array('RHR_WPF', 'sanitize_settings')));
    }

    public static function assets($hook) {
        if ($hook !== 'toplevel_page_' . self::SLUG) return;
        wp_enqueue_style('wp-color-picker');
        wp_enqueue_style('rhr-wpf-front', RHR_WPF_URL . 'assets/frontend.css', array(), RHR_WPF_VERSION);
        wp_enqueue_style('rhr-wpf-admin', RHR_WPF_URL . 'assets/admin.css', array('rhr-wpf-front'), RHR_WPF_VERSION);
        wp_enqueue_script('rhr-wpf-admin', RHR_WPF_URL . 'assets/admin.js', array('jquery', 'wp-color-picker'), RHR_WPF_VERSION, true);
    }

    public static function reset() {
        if (!current_user_can('manage_options')) wp_die('Forbidden');
        check_admin_referer('rhr_wpf_reset');
        $scope = isset($_POST['scope']) ? sanitize_key($_POST['scope']) : 'all';
        if ($scope === 'colors') {
            $s = RHR_WPF::settings();
            $d = RHR_WPF::defaults();
            foreach (RHR_WPF::COLOR_KEYS as $k) $s[$k] = $d[$k];
            foreach (array('radius', 'font_size', 'overlay_opacity', 'shadow', 'preset') as $k) $s[$k] = $d[$k];
            update_option('rhr_wpf_settings', $s);
        } else {
            update_option('rhr_wpf_settings', RHR_WPF::defaults());
        }
        wp_safe_redirect(add_query_arg('rhr-reset', '1', self::url(isset($_POST['tab']) ? sanitize_key($_POST['tab']) : '')));
        exit;
    }

    public static function palettes() {
        return array(
            'rose'     => array('Rose',        array('accent' => '#ff5a6e', 'accent_dark' => '#e5405a', 'text' => '#1f2430', 'heading' => '#111827', 'muted' => '#6b7280', 'border' => '#e7e9ef', 'panel' => '#ffffff', 'input_bg' => '#f6f7fa', 'button_text' => '#ffffff', 'chip_bg' => '#f3f4f7', 'trigger_bg' => '#111827', 'trigger_text' => '#ffffff', 'overlay' => '#0f172a')),
            'emerald'  => array('Emerald',     array('accent' => '#10b981', 'accent_dark' => '#059669', 'text' => '#1f2937', 'heading' => '#064e3b', 'muted' => '#6b7280', 'border' => '#e3ece8', 'panel' => '#ffffff', 'input_bg' => '#f4f8f6', 'button_text' => '#ffffff', 'chip_bg' => '#eef6f2', 'trigger_bg' => '#064e3b', 'trigger_text' => '#ffffff', 'overlay' => '#022c22')),
            'royal'    => array('Royal Blue',  array('accent' => '#4f46e5', 'accent_dark' => '#4338ca', 'text' => '#1e1b4b', 'heading' => '#111033', 'muted' => '#6b7280', 'border' => '#e5e7f5', 'panel' => '#ffffff', 'input_bg' => '#f5f6fd', 'button_text' => '#ffffff', 'chip_bg' => '#f0f1fb', 'trigger_bg' => '#1e1b4b', 'trigger_text' => '#ffffff', 'overlay' => '#0f0d2e')),
            'gold'     => array('Luxury Gold', array('accent' => '#c9a227', 'accent_dark' => '#a8841a', 'text' => '#2b2b2b', 'heading' => '#111111', 'muted' => '#77716a', 'border' => '#ece6d8', 'panel' => '#ffffff', 'input_bg' => '#faf8f2', 'button_text' => '#111111', 'chip_bg' => '#f6f1e4', 'trigger_bg' => '#111111', 'trigger_text' => '#e6c65c', 'overlay' => '#000000')),
            'midnight' => array('Midnight',    array('accent' => '#f472b6', 'accent_dark' => '#ec4899', 'text' => '#e5e7eb', 'heading' => '#ffffff', 'muted' => '#9ca3af', 'border' => '#273244', 'panel' => '#111827', 'input_bg' => '#0b1220', 'button_text' => '#ffffff', 'chip_bg' => '#1f2937', 'trigger_bg' => '#f472b6', 'trigger_text' => '#ffffff', 'overlay' => '#000000')),
            'sunset'   => array('Sunset',      array('accent' => '#f97316', 'accent_dark' => '#ea580c', 'text' => '#292524', 'heading' => '#1c1917', 'muted' => '#78716c', 'border' => '#efe6df', 'panel' => '#ffffff', 'input_bg' => '#fbf7f4', 'button_text' => '#ffffff', 'chip_bg' => '#f7efe9', 'trigger_bg' => '#7c2d12', 'trigger_text' => '#ffffff', 'overlay' => '#1c0a02')),
            'ocean'    => array('Ocean',       array('accent' => '#0ea5e9', 'accent_dark' => '#0284c7', 'text' => '#1e293b', 'heading' => '#0c4a6e', 'muted' => '#64748b', 'border' => '#e2ebf2', 'panel' => '#ffffff', 'input_bg' => '#f4f8fb', 'button_text' => '#ffffff', 'chip_bg' => '#eef5fa', 'trigger_bg' => '#0c4a6e', 'trigger_text' => '#ffffff', 'overlay' => '#082f49')),
            'mono'     => array('Monochrome',  array('accent' => '#111111', 'accent_dark' => '#000000', 'text' => '#262626', 'heading' => '#0a0a0a', 'muted' => '#737373', 'border' => '#e5e5e5', 'panel' => '#ffffff', 'input_bg' => '#f5f5f5', 'button_text' => '#ffffff', 'chip_bg' => '#f4f4f4', 'trigger_bg' => '#111111', 'trigger_text' => '#ffffff', 'overlay' => '#000000')),
        );
    }

    /* ---------------- field helpers ---------------- */

    private static function name($key, $multi = false) {
        return 'rhr_wpf_settings[' . $key . ']' . ($multi ? '[]' : '');
    }

    private static function toggle($s, $key, $title, $desc, $icon) {
        echo '<label class="rhr-toggle-card"><span class="rhr-control-icon">' . esc_html($icon) . '</span><span class="rhr-toggle-copy"><strong>' . esc_html($title) . '</strong><small>' . esc_html($desc) . '</small></span>';
        echo '<input type="hidden" name="' . esc_attr(self::name($key)) . '" value="0"><input type="checkbox" name="' . esc_attr(self::name($key)) . '" value="1" ' . checked($s[$key], 1, false) . '><i></i></label>';
    }

    private static function switch_row($s, $key, $title, $desc) {
        echo '<label class="rhr-switch-row"><input type="hidden" name="' . esc_attr(self::name($key)) . '" value="0"><input type="checkbox" name="' . esc_attr(self::name($key)) . '" value="1" ' . checked($s[$key], 1, false) . '><span><strong>' . esc_html($title) . '</strong><small>' . esc_html($desc) . '</small></span><i></i></label>';
    }

    private static function number($s, $key, $label, $unit, $help = '') {
        list($min, $max) = RHR_WPF::INT_KEYS[$key];
        echo '<label class="rhr-modern-field"><span>' . esc_html($label) . '</span><div><input type="number" min="' . (int) $min . '" max="' . (int) $max . '" name="' . esc_attr(self::name($key)) . '" value="' . esc_attr($s[$key]) . '" data-var="' . esc_attr($key) . '"><b>' . esc_html($unit) . '</b></div>' . ($help ? '<small>' . esc_html($help) . '</small>' : '') . '</label>';
    }

    private static function text($s, $key, $label, $help = '') {
        echo '<label class="rhr-modern-field"><span>' . esc_html($label) . '</span><input type="text" name="' . esc_attr(self::name($key)) . '" value="' . esc_attr($s[$key]) . '">' . ($help ? '<small>' . esc_html($help) . '</small>' : '') . '</label>';
    }

    private static function select($s, $key, $label, $options, $help = '') {
        echo '<label class="rhr-select-field"><span>' . esc_html($label) . '</span><select name="' . esc_attr(self::name($key)) . '">';
        foreach ($options as $v => $l) echo '<option value="' . esc_attr($v) . '" ' . selected($s[$key], $v, false) . '>' . esc_html($l) . '</option>';
        echo '</select>' . ($help ? '<small>' . esc_html($help) . '</small>' : '') . '</label>';
    }

    private static function segmented($s, $key, $label, $options) {
        echo '<div class="rhr-seg-field"><span>' . esc_html($label) . '</span><div class="rhr-seg">';
        foreach ($options as $v => $o) {
            echo '<label><input type="radio" name="' . esc_attr(self::name($key)) . '" value="' . esc_attr($v) . '" ' . checked($s[$key], $v, false) . '><span><b>' . esc_html($o[0]) . '</b>' . (isset($o[1]) ? '<small>' . esc_html($o[1]) . '</small>' : '') . '</span></label>';
        }
        echo '</div></div>';
    }

    private static function color($s, $key, $label) {
        $id = 'rhr-c-' . $key;
        echo '<div class="rhr-color-field"><span class="rhr-color-label" id="' . esc_attr($id) . '-l">' . esc_html($label) . '</span><input class="rhr-color-input" id="' . esc_attr($id) . '" aria-labelledby="' . esc_attr($id) . '-l" type="text" name="' . esc_attr(self::name($key)) . '" value="' . esc_attr($s[$key]) . '" data-key="' . esc_attr($key) . '" data-default-color="' . esc_attr(RHR_WPF::defaults()[$key]) . '"></div>';
    }

    private static function head($eyebrow, $title, $desc) {
        echo '<div class="rhr-page-heading"><div><span class="rhr-eyebrow">' . esc_html($eyebrow) . '</span><h2>' . esc_html($title) . '</h2><p>' . esc_html($desc) . '</p></div><button class="button button-primary rhr-save-top" type="submit">' . esc_html__('Save changes', 'rhr-woocommerce-product-filter') . '</button></div>';
    }

    /* ---------------- preview ---------------- */

    public static function preview($s) {
        $vars = '';
        foreach (RHR_WPF::css_vars($s) as $k => $v) $vars .= $k . ':' . $v . ';';
        $I = array('RHR_WPF_Render', 'icon');
        ?>
        <div class="rhr-preview-stage">
          <div class="rhr-preview-frame rhr-scope rhr-preset-<?php echo esc_attr($s['preset']); ?>" id="rhr-live-preview" style="<?php echo esc_attr($vars); ?>">
            <div class="rhr-preview-bar">
              <button type="button" class="rhr-trigger" tabindex="-1"><span class="rhr-trigger-icon"><?php echo call_user_func($I, 'filter'); // phpcs:ignore ?></span><span class="rhr-trigger-label" data-label="drawer_button"><?php echo esc_html($s['drawer_button']); ?></span><span class="rhr-filter-count">3</span></button>
              <span class="rhr-preview-sort">Sort by latest</span>
            </div>
            <div class="rhr-filter-panel">
              <div class="rhr-filter-head"><h3 class="rhr-filter-title" data-label="title"><?php echo esc_html($s['title']); ?></h3><button type="button" class="rhr-reset-link" tabindex="-1"><?php echo esc_html($s['label_reset']); ?></button></div>
              <div class="rhr-active"><div class="rhr-active-list"><button type="button" class="rhr-active-chip" tabindex="-1"><span>Three Piece</span><i>×</i></button><button type="button" class="rhr-active-chip" tabindex="-1"><span>Size: M</span><i>×</i></button></div></div>
              <div class="rhr-sec"><div class="rhr-search"><span class="rhr-search-icon"><?php echo call_user_func($I, 'search'); // phpcs:ignore ?></span><input type="search" name="p" readonly placeholder="<?php echo esc_attr($s['search_placeholder']); ?>" tabindex="-1"><button type="button" class="rhr-search-go" tabindex="-1"><?php echo call_user_func($I, 'arrow'); // phpcs:ignore ?></button></div></div>
              <div class="rhr-sec"><div class="rhr-sec-head is-static"><span class="rhr-section-title"><?php echo esc_html($s['label_categories']); ?></span><span class="rhr-sec-meta">1</span></div>
                <ul class="rhr-terms">
                  <li class="rhr-term"><label class="rhr-check"><input type="checkbox" checked tabindex="-1"><span class="rhr-box"></span><span class="rhr-term-name">Three Piece</span><em class="rhr-count">12</em></label></li>
                  <li class="rhr-term is-current"><label class="rhr-check"><input type="checkbox" tabindex="-1"><span class="rhr-box"></span><span class="rhr-term-name">Women Dress</span><em class="rhr-count">10</em></label></li>
                  <li class="rhr-term"><label class="rhr-check"><input type="checkbox" tabindex="-1"><span class="rhr-box"></span><span class="rhr-term-name">Kids item</span><em class="rhr-count">24</em></label></li>
                </ul>
              </div>
              <div class="rhr-sec"><div class="rhr-sec-head is-static"><span class="rhr-section-title">Size</span></div>
                <div class="rhr-chips"><?php foreach (array('S' => 0, 'M' => 1, 'L' => 0, 'XL' => 0) as $n => $on) : ?><label class="rhr-chip"><input type="checkbox" <?php checked($on, 1); ?> tabindex="-1"><span class="rhr-chip-inner"><span class="rhr-chip-name"><?php echo esc_html($n); ?></span></span></label><?php endforeach; ?></div>
              </div>
              <div class="rhr-sec"><div class="rhr-sec-head is-static"><span class="rhr-section-title"><?php echo esc_html($s['label_price']); ?></span></div>
                <div class="rhr-price"><div class="rhr-range"><div class="rhr-range-track"><div class="rhr-range-fill" style="left:18%;right:30%"></div></div></div>
                  <div class="rhr-price-inputs"><label><span class="rhr-cur">৳</span><input type="number" name="a" value="500" readonly tabindex="-1"></label><span class="rhr-dash">–</span><label><span class="rhr-cur">৳</span><input type="number" name="b" value="2500" readonly tabindex="-1"></label></div></div>
              </div>
              <div class="rhr-sec"><label class="rhr-switch"><input type="checkbox" checked tabindex="-1"><span class="rhr-switch-ui"></span><span><?php echo esc_html($s['label_in_stock']); ?></span></label></div>
              <div class="rhr-panel-foot rhr-preview-foot"><button type="button" class="rhr-btn rhr-btn-ghost" tabindex="-1"><?php echo esc_html($s['label_reset']); ?></button><button type="button" class="rhr-btn rhr-btn-primary" tabindex="-1"><?php echo esc_html($s['label_apply']); ?></button></div>
            </div>
          </div>
        </div>
        <?php
    }

    /* ---------------- page ---------------- */

    public static function page() {
        if (!current_user_can('manage_options')) return;
        $s   = RHR_WPF::settings();
        $tab = isset($_GET['tab']) ? sanitize_key($_GET['tab']) : 'overview'; // phpcs:ignore
        $tabs = array(
            'overview' => array(__('Overview', 'rhr-woocommerce-product-filter'), 'dashicons-dashboard'),
            'filters'  => array(__('Filter Elements', 'rhr-woocommerce-product-filter'), 'dashicons-filter'),
            'layout'   => array(__('Layout & Mobile', 'rhr-woocommerce-product-filter'), 'dashicons-smartphone'),
            'design'   => array(__('Design & Colors', 'rhr-woocommerce-product-filter'), 'dashicons-art'),
            'labels'   => array(__('Labels & Text', 'rhr-woocommerce-product-filter'), 'dashicons-editor-textcolor'),
            'setup'    => array(__('Setup & Help', 'rhr-woocommerce-product-filter'), 'dashicons-sos'),
        );
        if (!isset($tabs[$tab])) $tab = 'overview';
        $saved = isset($_GET['settings-updated']) || isset($_GET['rhr-reset']); // phpcs:ignore
        $active_filters = (int) $s['show_search'] + (int) $s['show_categories'] + (int) $s['show_attributes'] + (int) $s['show_price'] + (int) $s['show_stock'] + (int) $s['show_sale'] + (int) $s['show_rating'];
        $elementor = did_action('elementor/loaded');
        ?>
<div class="wrap rhr-wpf-admin">
  <div class="rhr-admin-shell">
    <header class="rhr-admin-hero">
      <div class="rhr-hero-copy">
        <div class="rhr-brand-mark">RHR</div>
        <div>
          <div class="rhr-kicker">WOOCOMMERCE FILTER SYSTEM</div>
          <h1>RHR Product Filter</h1>
          <p>Fast, beautiful product filtering for desktop, tablet and mobile — with Elementor support.</p>
          <div class="rhr-version-pill">Version <?php echo esc_html(RHR_WPF_VERSION); ?> <span>| By Rubel Hasan Rokib</span></div>
        </div>
      </div>
      <div class="rhr-hero-status">
        <span class="rhr-status-dot<?php echo class_exists('WooCommerce') ? '' : ' is-off'; ?>"></span><strong><?php echo class_exists('WooCommerce') ? 'Plugin ready' : 'WooCommerce missing'; ?></strong>
        <small><?php echo $s['ajax_archive'] ? 'AJAX results enabled' : 'Page-reload mode'; ?> · <?php echo $elementor ? 'Elementor widget on' : 'Shortcode mode'; ?></small>
      </div>
    </header>

    <?php if ($saved) : ?><div class="rhr-toast"><span class="dashicons dashicons-yes-alt"></span> <?php echo isset($_GET['rhr-reset']) ? esc_html__('Settings reset to defaults.', 'rhr-woocommerce-product-filter') : esc_html__('Settings saved.', 'rhr-woocommerce-product-filter'); // phpcs:ignore ?></div><?php endif; ?>

    <div class="rhr-admin-body">
      <aside class="rhr-admin-nav">
        <div class="rhr-nav-label">CONTROL PANEL</div>
        <?php foreach ($tabs as $key => $t) : ?>
          <a class="<?php echo $tab === $key ? 'is-active' : ''; ?>" href="<?php echo esc_url(self::url($key)); ?>"><span class="dashicons <?php echo esc_attr($t[1]); ?>"></span><span><?php echo esc_html($t[0]); ?></span></a>
        <?php endforeach; ?>
        <div class="rhr-nav-tip"><strong>Quick tip</strong><span>Every color here is the default. In Elementor, the “RHR Product Filter” widget can override colors per page.</span></div>
      </aside>

      <main class="rhr-admin-main">
        <form method="post" action="options.php" id="rhr-wpf-settings-form">
          <?php settings_fields('rhr_wpf_group'); ?>

          <?php if ($tab === 'overview') : ?>
            <?php self::head('WELCOME BACK', 'Filter dashboard', 'Manage features, responsive behavior and the visual style of your WooCommerce filter from one place.'); ?>
            <div class="rhr-stat-grid">
              <div class="rhr-stat-card"><span class="rhr-stat-icon dashicons dashicons-filter"></span><strong><?php echo (int) $active_filters; ?></strong><span>Active filter sections</span></div>
              <div class="rhr-stat-card"><span class="rhr-stat-icon dashicons dashicons-smartphone"></span><strong><?php echo esc_html(ucfirst($s['mobile_layout'])); ?> · <?php echo esc_html(ucfirst($s['drawer_side'])); ?></strong><span>Mobile filter style</span></div>
              <div class="rhr-stat-card"><span class="rhr-stat-icon dashicons dashicons-image-flip-horizontal"></span><strong><?php echo (int) RHR_WPF::breakpoint($s); ?>px</strong><span>Phone-style layout up to</span></div>
              <div class="rhr-stat-card"><span class="rhr-stat-icon dashicons dashicons-performance"></span><strong><?php echo $s['ajax_archive'] ? 'AJAX' : 'Reload'; ?></strong><span>Results update</span></div>
            </div>
            <div class="rhr-content-grid">
              <section class="rhr-card"><div class="rhr-card-head"><div><h3>Live style preview</h3><p>Exactly the classes used on your store</p></div><span class="rhr-live-badge">LIVE</span></div><?php self::preview($s); ?></section>
              <section class="rhr-card"><div class="rhr-card-head"><div><h3>Setup checklist</h3><p>Recommended before publishing</p></div></div>
                <div class="rhr-checklist">
                  <div class="<?php echo class_exists('WooCommerce') ? 'done' : ''; ?>"><span><?php echo class_exists('WooCommerce') ? '✓' : '1'; ?></span><div><strong>WooCommerce active</strong><small>Products, categories and attributes are available.</small></div></div>
                  <div class="done"><span>✓</span><div><strong>Mobile drawer fixed</strong><small>No auto slide/flash on page load. Opens only when tapped.</small></div></div>
                  <div class="done"><span>✓</span><div><strong>Live search</strong><small>Suggestions while typing, applies on Enter / arrow button.</small></div></div>
                  <div class="<?php echo $elementor ? 'done' : ''; ?>"><span><?php echo $elementor ? '✓' : '4'; ?></span><div><strong>Place the filter</strong><small><?php echo $elementor ? 'Drag the “RHR Product Filter” widget into your Product Archive template.' : 'Paste [rhr_product_filter] into your shop sidebar.'; ?></small></div></div>
                </div>
                <div class="rhr-shortcode-box"><code>[rhr_product_filter]</code><button type="button" class="button rhr-copy" data-copy="[rhr_product_filter]">Copy</button></div>
              </section>
            </div>
          <?php endif; ?>

          <?php if ($tab === 'filters') : ?>
            <?php self::head('CONTROL WHAT SHOPPERS SEE', 'Filter elements', 'Turn filter sections on or off and choose which product attributes appear.'); ?>
            <section class="rhr-card"><div class="rhr-card-head"><div><h3>Filter sections</h3><p>Shown in this order inside the panel.</p></div></div><div class="rhr-toggle-grid">
              <?php
              self::toggle($s, 'show_search', 'Live product search', 'Suggestions with image & price while typing. Also matches SKU.', '⌕');
              self::toggle($s, 'show_categories', 'Product categories', 'Hierarchical tree with sub-categories.', '▤');
              self::toggle($s, 'show_attributes', 'Attributes (size, color…)', 'Chips, checkboxes or color swatches.', 'S');
              self::toggle($s, 'show_price', 'Price range', 'Dual slider + min/max inputs.', '৳');
              self::toggle($s, 'show_stock', 'In stock only', 'Availability switch.', '✓');
              self::toggle($s, 'show_sale', 'On sale only', 'Show discounted products only.', '%');
              self::toggle($s, 'show_rating', 'Rating', 'Filter by minimum star rating.', '★');
              self::toggle($s, 'show_active', 'Active filter chips', 'Removable chips at the top of the panel.', '◉');
              self::toggle($s, 'show_counts', 'Product counts', 'Numbers beside categories & attributes.', '#');
              self::toggle($s, 'show_reset', 'Reset button', 'One-click “Reset all”.', '↺');
              self::toggle($s, 'show_sort', 'Sort dropdown (grid mode)', 'For the standalone shortcode grid. Archive pages use WooCommerce’s own sort.', '↕');
              ?>
            </div></section>

            <div class="rhr-form-grid">
              <section class="rhr-card"><div class="rhr-card-head"><div><h3>Attributes</h3><p>Pick the WooCommerce attributes to show.</p></div></div>
                <input type="hidden" name="<?php echo esc_attr(self::name('attributes', true)); ?>" value="">
                <div class="rhr-attr-list">
                <?php
                $attrs = function_exists('wc_get_attribute_taxonomies') ? wc_get_attribute_taxonomies() : array();
                if (!$attrs) echo '<p class="rhr-muted">No product attributes yet. Create them in Products → Attributes (e.g. Size, Color).</p>';
                foreach ($attrs as $a) {
                    $on = in_array($a->attribute_name, (array) $s['attributes'], true);
                    echo '<label class="rhr-attr"><input type="checkbox" name="' . esc_attr(self::name('attributes', true)) . '" value="' . esc_attr($a->attribute_name) . '" ' . checked($on, true, false) . '><span><b>' . esc_html($a->attribute_label) . '</b><small>pa_' . esc_html($a->attribute_name) . '</small></span></label>';
                }
                ?>
                </div>
                <?php self::select($s, 'attribute_style', 'Display style', array('chips' => 'Chips / buttons (recommended)', 'checkbox' => 'Checkbox list')); ?>
                <?php self::switch_row($s, 'color_swatches', 'Color swatches', 'Attributes named “Color / Colour / রং” show colored dots (term name or swatch meta).'); ?>
              </section>
              <section class="rhr-card"><div class="rhr-card-head"><div><h3>Categories & sections</h3><p>Tree, “show more” and collapsible sections.</p></div></div>
                <?php
                self::switch_row($s, 'cat_hierarchy', 'Show sub-categories as a tree', 'Parent categories expand to their children.');
                self::switch_row($s, 'hide_empty', 'Hide empty categories', 'Categories with no products are hidden.');
                self::number($s, 'cat_limit', '“Show more” after', 'items', '0 = show all top-level categories.');
                self::switch_row($s, 'collapsible', 'Collapsible sections', 'Shoppers can fold each section.');
                self::switch_row($s, 'collapsed_default', 'Start collapsed', 'Sections start folded (search stays open).');
                self::switch_row($s, 'search_sku', 'Search by SKU', 'Search also matches product & variation SKUs.');
                self::number($s, 'search_min_chars', 'Suggestions start after', 'chars');
                self::select($s, 'search_scope', 'On category pages, search in', array('all' => 'Whole shop (recommended)', 'current' => 'Current category only'));
                ?>
              </section>
            </div>
          <?php endif; ?>

          <?php if ($tab === 'layout') : ?>
            <?php self::head('RESPONSIVE EXPERIENCE', 'Layout & mobile', 'Desktop sidebar, mobile drawer and how results update.'); ?>
            <div class="rhr-form-grid">
              <section class="rhr-card"><div class="rhr-card-head"><div><h3>Mobile</h3><p>Phones & small tablets.</p></div></div>
                <?php
                self::number($s, 'mobile_breakpoint', 'Mobile breakpoint', 'px', 'Screens up to this width use the mobile layout. Elementor mobile = 767.');
                self::switch_row($s, 'tablet_drawer', 'Tablets use the phone layout too', 'Filter button + slide-in drawer on tablets instead of a full-width panel.');
                self::number($s, 'tablet_breakpoint', 'Tablet breakpoint', 'px', 'Used when the option above is on. Elementor tablet = 1024.');
                self::segmented($s, 'mobile_layout', 'Mobile filter style', array('drawer' => array('Drawer', 'Slide-in panel'), 'inline' => array('Inline', 'Expands in place')));
                self::segmented($s, 'drawer_side', 'Drawer opens from', array('right' => array('Right'), 'left' => array('Left'), 'bottom' => array('Bottom', 'App-style sheet')));
                self::select($s, 'trigger_position', 'Filter button position', array('auto' => 'Auto — above the product grid (recommended)', 'inline' => 'Where the widget / shortcode is placed', 'floating' => 'Floating button at the bottom'));
                self::segmented($s, 'mobile_apply', 'In the drawer, results update', array('button' => array('On “Show results”', 'Pick several, then apply'), 'instant' => array('Instantly', 'Every tap')));
                self::switch_row($s, 'move_ordering', 'Put “Sort by” next to the Filter button', 'Moves WooCommerce’s sort dropdown into the mobile filter bar.');
                ?>
              </section>
              <section class="rhr-card"><div class="rhr-card-head"><div><h3>Desktop</h3><p>Sidebar next to your products.</p></div></div>
                <?php
                self::segmented($s, 'desktop_mode', 'Desktop filter style', array('sidebar' => array('Sidebar', 'Always visible'), 'drawer' => array('Drawer', 'Button + slide-in')));
                self::switch_row($s, 'sticky_desktop', 'Sticky sidebar', 'Filter panel stays visible while scrolling.');
                self::number($s, 'desktop_width', 'Sidebar width (grid mode)', 'px');
                self::number($s, 'columns', 'Product columns (grid mode)', 'cols');
                self::number($s, 'per_page', 'Products per page (grid mode)', 'items');
                self::number($s, 'gap', 'Sidebar gap (grid mode)', 'px');
                ?>
              </section>
            </div>
            <section class="rhr-card"><div class="rhr-card-head"><div><h3>Shop / category page integration</h3><p>Works with Elementor Pro “Archive Products”, Loop Grid and classic WooCommerce templates.</p></div></div>
              <div class="rhr-form-grid"><div>
                <?php
                self::switch_row($s, 'ajax_archive', 'Update products without page reload (AJAX)', 'Only the product grid refreshes. Falls back to a normal reload automatically if needed.');
                self::switch_row($s, 'auto_archive', 'Auto-add filter to classic shop pages', 'For non-Elementor themes: adds a Filter button + drawer above the products.');
                ?>
              </div><div>
                <?php self::text($s, 'products_selector', 'Custom products container selector (optional)', 'Leave empty for auto-detect. Example: .my-products-grid'); ?>
              </div></div>
            </section>
          <?php endif; ?>

          <?php if ($tab === 'design') : ?>
            <?php self::head('MAKE IT YOUR BRAND', 'Design & colors', 'Pick a palette in one click, then fine-tune every color. The preview updates live.'); ?>
            <div class="rhr-design-grid">
              <div>
                <section class="rhr-card"><div class="rhr-card-head"><div><h3>One-click palettes</h3><p>Applies to the pickers below — click Save to keep.</p></div></div>
                  <div class="rhr-palettes">
                  <?php foreach (self::palettes() as $key => $p) : ?>
                    <button type="button" class="rhr-palette" data-colors="<?php echo esc_attr(wp_json_encode($p[1])); ?>">
                      <span class="rhr-pal-sw"><i style="background:<?php echo esc_attr($p[1]['panel']); ?>"></i><i style="background:<?php echo esc_attr($p[1]['accent']); ?>"></i><i style="background:<?php echo esc_attr($p[1]['trigger_bg']); ?>"></i><i style="background:<?php echo esc_attr($p[1]['chip_bg']); ?>"></i></span>
                      <b><?php echo esc_html($p[0]); ?></b>
                    </button>
                  <?php endforeach; ?>
                  </div>
                </section>
                <section class="rhr-card"><div class="rhr-card-head"><div><h3>Style preset</h3><p>Shape & surface style.</p></div></div>
                  <div class="rhr-preset-grid">
                  <?php foreach (array('clean' => array('Clean', 'Bordered card'), 'soft' => array('Soft', 'Shadows, no borders'), 'minimal' => array('Minimal', 'No card, flat'), 'bold' => array('Bold', 'Strong outlines')) as $k => $p) : ?>
                    <label class="rhr-preset-card <?php echo $s['preset'] === $k ? 'selected' : ''; ?>"><input type="radio" name="<?php echo esc_attr(self::name('preset')); ?>" value="<?php echo esc_attr($k); ?>" <?php checked($s['preset'], $k); ?>><span class="rhr-preset-demo rhr-demo-<?php echo esc_attr($k); ?>"><i></i><i></i><i></i></span><strong><?php echo esc_html($p[0]); ?></strong><small><?php echo esc_html($p[1]); ?></small></label>
                  <?php endforeach; ?>
                  </div>
                </section>
                <section class="rhr-card"><div class="rhr-card-head"><div><h3>Color system</h3><p>Every color used by the filter.</p></div></div>
                  <h4 class="rhr-subhead">Brand</h4>
                  <div class="rhr-color-grid"><?php self::color($s, 'accent', 'Accent (buttons, checks)'); self::color($s, 'accent_dark', 'Accent hover'); self::color($s, 'button_text', 'Text on accent'); ?></div>
                  <h4 class="rhr-subhead">Text</h4>
                  <div class="rhr-color-grid"><?php self::color($s, 'heading', 'Headings'); self::color($s, 'text', 'Body text'); self::color($s, 'muted', 'Muted text / counts'); ?></div>
                  <h4 class="rhr-subhead">Surfaces</h4>
                  <div class="rhr-color-grid"><?php self::color($s, 'panel', 'Panel background'); self::color($s, 'input_bg', 'Input background'); self::color($s, 'chip_bg', 'Chips / badges'); self::color($s, 'border', 'Borders & lines'); ?></div>
                  <h4 class="rhr-subhead">Mobile Filter button & overlay</h4>
                  <div class="rhr-color-grid"><?php self::color($s, 'trigger_bg', 'Filter button'); self::color($s, 'trigger_text', 'Filter button text'); self::color($s, 'overlay', 'Drawer overlay'); ?></div>
                </section>
                <section class="rhr-card"><div class="rhr-card-head"><div><h3>Shape & size</h3><p>Corners, text size and depth.</p></div></div>
                  <div class="rhr-form-grid"><div><?php self::number($s, 'radius', 'Corner radius', 'px'); self::number($s, 'font_size', 'Base font size', 'px'); ?></div><div><?php self::number($s, 'overlay_opacity', 'Overlay opacity', '%'); self::switch_row($s, 'shadow', 'Soft shadows', 'Panel and drawer shadows.'); ?></div></div>
                </section>
              </div>
              <div class="rhr-sticky-preview"><section class="rhr-card"><div class="rhr-card-head"><div><h3>Live preview</h3><p>Updates as you change colors</p></div><span class="rhr-live-badge">LIVE</span></div><?php self::preview($s); ?></section></div>
            </div>
          <?php endif; ?>

          <?php if ($tab === 'labels') : ?>
            <?php self::head('TEXT & LANGUAGE', 'Labels & text', 'Write every customer-facing word in your store language (Bangla works perfectly).'); ?>
            <div class="rhr-form-grid">
              <section class="rhr-card"><div class="rhr-card-head"><div><h3>Panel</h3><p>Titles and buttons.</p></div></div>
                <?php
                self::text($s, 'title', 'Filter title');
                self::text($s, 'drawer_button', 'Mobile “Filters” button');
                self::text($s, 'label_apply', 'Apply button (drawer)');
                self::text($s, 'label_reset', 'Reset button');
                self::text($s, 'label_active', 'Active filters heading');
                self::text($s, 'label_show_more', '“Show more” link');
                self::text($s, 'label_show_less', '“Show less” link');
                ?>
              </section>
              <section class="rhr-card"><div class="rhr-card-head"><div><h3>Sections</h3><p>Section titles and options.</p></div></div>
                <?php
                self::text($s, 'label_search', 'Search title');
                self::text($s, 'search_placeholder', 'Search placeholder');
                self::text($s, 'label_view_all', '“See all results for” text');
                self::text($s, 'label_categories', 'Categories title');
                self::text($s, 'label_price', 'Price title');
                self::text($s, 'label_stock', 'Availability title');
                self::text($s, 'label_in_stock', '“In stock only” text');
                self::text($s, 'label_sale', '“On sale only” text');
                self::text($s, 'label_rating', 'Rating title');
                self::text($s, 'label_any_rating', '“Any rating” text');
                self::text($s, 'label_no_results', 'No products text');
                ?>
              </section>
            </div>
          <?php endif; ?>

          <?php if ($tab === 'setup') : ?>
            <?php self::head('INSTALLATION', 'Setup & help', 'Two ways to add the filter to your store.'); ?>
            <div class="rhr-form-grid">
              <section class="rhr-card rhr-help"><div class="rhr-card-head"><div><h3>A) Elementor (recommended)</h3><p>Elementor Pro Theme Builder → Product Archive</p></div></div>
                <ol>
                  <li>Open your <b>Product Archive</b> template in Elementor.</li>
                  <li>Make a 2-column layout: left container for the filter, right container with the <b>Archive Products</b> (or Loop Grid) widget.</li>
                  <li>Search the widget panel for <b>“RHR Product Filter”</b> and drag it into the left container.</li>
                  <li>Optional: set the left container to <b>hidden on mobile</b> — the filter automatically becomes a <b>Filter</b> button above the products with a slide-in drawer.</li>
                  <li>Style tab of the widget lets you override colors, typography and spacing for that template.</li>
                </ol>
              </section>
              <section class="rhr-card rhr-help"><div class="rhr-card-head"><div><h3>B) Shortcode</h3><p>Any theme / page builder</p></div></div>
                <div class="rhr-shortcode-box"><code>[rhr_product_filter]</code><button type="button" class="button rhr-copy" data-copy="[rhr_product_filter]">Copy</button></div>
                <p class="rhr-muted">On shop / category pages it filters the existing product grid. On a normal page it shows its own product grid:</p>
                <div class="rhr-shortcode-box"><code>[rhr_product_filter mode="grid" category="three-piece" columns="4" per_page="12"]</code><button type="button" class="button rhr-copy" data-copy='[rhr_product_filter mode="grid" category="three-piece" columns="4" per_page="12"]'>Copy</button></div>
                <p class="rhr-muted">Other attributes: <code>drawer_side="left|right|bottom"</code> <code>trigger="auto|inline|floating"</code> <code>desktop_mode="sidebar|drawer"</code> <code>title="…"</code></p>
              </section>
            </div>
          <?php endif; ?>

          <?php if ($tab !== 'setup') : ?>
          <div class="rhr-bottom-save"><span>All settings are saved to WordPress.</span><button class="button button-primary" type="submit">Save changes</button></div>
          <?php endif; ?>
        </form>

        <?php if (in_array($tab, array('design', 'setup'), true)) : ?>
        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="rhr-reset-form" onsubmit="return confirm('Reset <?php echo $tab === 'design' ? 'colors & design' : 'ALL settings'; ?> to defaults?');">
          <?php wp_nonce_field('rhr_wpf_reset'); ?>
          <input type="hidden" name="action" value="rhr_wpf_reset"><input type="hidden" name="tab" value="<?php echo esc_attr($tab); ?>">
          <input type="hidden" name="scope" value="<?php echo $tab === 'design' ? 'colors' : 'all'; ?>">
          <button type="submit" class="button rhr-reset-btn"><?php echo $tab === 'design' ? 'Reset colors & design to default' : 'Reset all settings to default'; ?></button>
        </form>
        <?php endif; ?>
      </main>
    </div>
  </div>
</div>
        <?php
    }
}
