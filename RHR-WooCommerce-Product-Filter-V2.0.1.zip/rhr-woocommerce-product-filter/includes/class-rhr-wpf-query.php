<?php
/**
 * Applies filter requests to the real WooCommerce / Elementor product query.
 *
 * URL parameters (all optional):
 *   rhr_s              search text
 *   rhr_cat[]          product_cat term IDs (replace the current archive category)
 *   rhr_attr_{name}[]  attribute term slugs, e.g. rhr_attr_size[]=m  (legacy: rhr_size[])
 *   rhr_min_price / rhr_max_price
 *   rhr_stock=1, rhr_sale=1, rhr_rating=4
 *   orderby            native WooCommerce ordering
 */
if (!defined('ABSPATH')) exit;

class RHR_WPF_Query {

    private static $request = null;

    public static function init() {
        add_action('pre_get_posts', array(__CLASS__, 'pre_get_posts'), 999);
        add_filter('posts_clauses', array(__CLASS__, 'price_clauses'), 20, 2);
        add_filter('posts_search', array(__CLASS__, 'sku_search'), 20, 2);
    }

    /** Normalize a raw request array (from $_GET or an AJAX payload). */
    public static function normalize($src) {
        $src = is_array($src) ? $src : array();
        $r   = array('s' => '', 'cats' => array(), 'attrs' => array(), 'min' => null, 'max' => null, 'stock' => false, 'sale' => false, 'rating' => 0, 'orderby' => '');

        if (isset($src['rhr_s']) && !is_array($src['rhr_s'])) {
            $r['s'] = trim(sanitize_text_field(wp_unslash($src['rhr_s'])));
        }
        if (isset($src['rhr_cat'])) {
            $r['cats'] = array_values(array_unique(array_filter(array_map('absint', (array) $src['rhr_cat']))));
        }
        foreach ($src as $key => $val) {
            $name = null;
            if (strpos((string) $key, 'rhr_attr_') === 0) $name = substr($key, 9);
            elseif ($key === 'rhr_size') $name = 'size';
            if ($name === null) continue;
            $tax = wc_attribute_taxonomy_name(sanitize_title($name));
            if (!taxonomy_exists($tax)) continue;
            $slugs = array_values(array_filter(array_map('sanitize_title', array_map('wp_unslash', (array) $val))));
            if ($slugs) $r['attrs'][$tax] = isset($r['attrs'][$tax]) ? array_values(array_unique(array_merge($r['attrs'][$tax], $slugs))) : $slugs;
        }
        foreach (array('min' => 'rhr_min_price', 'max' => 'rhr_max_price') as $k => $param) {
            if (isset($src[$param]) && !is_array($src[$param]) && $src[$param] !== '' && is_numeric($src[$param])) {
                $r[$k] = max(0, (float) $src[$param]);
            }
        }
        if ($r['min'] !== null && $r['max'] !== null && $r['min'] > $r['max']) {
            list($r['min'], $r['max']) = array($r['max'], $r['min']);
        }
        $r['stock']  = !empty($src['rhr_stock']);
        $r['sale']   = !empty($src['rhr_sale']);
        $r['rating'] = isset($src['rhr_rating']) ? max(0, min(5, intval($src['rhr_rating']))) : 0;
        if (isset($src['orderby']) && !is_array($src['orderby'])) $r['orderby'] = sanitize_key($src['orderby']);
        return $r;
    }

    public static function request() {
        if (self::$request === null) self::$request = self::normalize($_GET); // phpcs:ignore
        return self::$request;
    }

    public static function has_filters($r) {
        return $r['s'] !== '' || $r['cats'] || $r['attrs'] || $r['min'] !== null || $r['max'] !== null || $r['stock'] || $r['sale'] || $r['rating'];
    }

    public static function is_product_archive() {
        if (!function_exists('is_shop')) return false;
        return is_shop() || is_product_taxonomy() || (is_search() && get_query_var('post_type') === 'product');
    }

    public static function pre_get_posts($q) {
        if (!$q instanceof WP_Query) return;

        // Standalone grid queries carry their own request.
        $own = $q->get('rhr_wpf_request');
        if (is_array($own) && !$q->get('rhr_wpf_applied')) {
            self::apply($q, $own);
            return;
        }

        if (is_admin() || wp_doing_ajax() || $q->get('rhr_wpf_applied')) return;
        $r = self::request();
        if (!self::has_filters($r)) return;
        if (!self::is_product_archive()) return;

        // Main archive query, plus product queries that Elementor Pro's
        // Archive Products / Loop Grid widgets build from the current query.
        if (!$q->is_main_query() && !self::is_product_query($q)) return;
        self::apply($q, $r);
    }

    private static function is_product_query($q) {
        if ($q->get('wc_query') === 'product_query') return true;
        $pt = $q->get('post_type');
        $is_product = $pt === 'product' || (is_array($pt) && in_array('product', $pt, true));
        // Ignore tiny helper queries (menus, "related" widgets…): only paginated catalog-sized lists.
        return $is_product && !$q->get('rhr_wpf_skip') && (int) $q->get('posts_per_page') !== 1;
    }

    /** Apply a normalized request to a WP_Query before it runs. */
    public static function apply($q, $r) {
        if ($r['s'] !== '') {
            $q->set('s', $r['s']);
            $q->set('rhr_wpf_sku', !empty(RHR_WPF::settings()['search_sku']));
        }

        $tax = $q->get('tax_query');
        $tax = is_array($tax) ? $tax : array();

        $whole_shop = $r['s'] !== '' && !$r['cats'] && RHR_WPF::settings()['search_scope'] === 'all' && !$q->get('rhr_wpf_request');
        if ($r['cats'] || $whole_shop) {
            // A chosen category (or a whole-shop search) replaces the archive's category constraint
            // (e.g. from "Three Piece" to "Kids item").
            $clean = array();
            foreach ($tax as $k => $clause) {
                if ($k === 'relation') continue;
                if (is_array($clause) && isset($clause['taxonomy']) && $clause['taxonomy'] === 'product_cat') continue;
                $clean[] = $clause;
            }
            $tax = $clean;
            $q->set('product_cat', '');
            if ($q->get('taxonomy') === 'product_cat') {
                $q->set('taxonomy', '');
                $q->set('term', '');
            }
            if ($r['cats']) {
                $tax[] = array('taxonomy' => 'product_cat', 'field' => 'term_id', 'terms' => $r['cats'], 'operator' => 'IN', 'include_children' => true);
            }
        }
        foreach ($r['attrs'] as $taxonomy => $slugs) {
            $tax[] = array('taxonomy' => $taxonomy, 'field' => 'slug', 'terms' => $slugs, 'operator' => 'IN');
        }
        if (count($tax) > 1 && !isset($tax['relation'])) $tax['relation'] = 'AND';
        $q->set('tax_query', $tax);

        $meta = $q->get('meta_query');
        $meta = is_array($meta) ? $meta : array();
        if ($r['stock'])  $meta[] = array('key' => '_stock_status', 'value' => array('instock', 'onbackorder'), 'compare' => 'IN');
        if ($r['rating']) $meta[] = array('key' => '_wc_average_rating', 'value' => $r['rating'] - 0.01, 'compare' => '>=', 'type' => 'DECIMAL(3,2)');
        if (count($meta) > 1 && !isset($meta['relation'])) $meta['relation'] = 'AND';
        $q->set('meta_query', $meta);

        if ($r['min'] !== null || $r['max'] !== null) {
            $q->set('rhr_wpf_price', array($r['min'], $r['max']));
        }

        if ($r['sale']) {
            $ids = array_map('intval', wc_get_product_ids_on_sale());
            $cur = array_filter(array_map('intval', (array) $q->get('post__in')));
            $ids = $cur ? array_values(array_intersect($cur, $ids)) : $ids;
            $q->set('post__in', $ids ? $ids : array(0));
        }

        $q->set('rhr_wpf_applied', 1);
    }

    /**
     * Correct price filtering for simple AND variable products using the
     * WooCommerce lookup table (v1.x compared every _price row separately,
     * which let variable products slip through the range).
     */
    public static function price_clauses($clauses, $q) {
        $range = $q->get('rhr_wpf_price');
        if (!is_array($range)) return $clauses;
        global $wpdb;
        $lookup = $wpdb->prefix . 'wc_product_meta_lookup';
        $clauses['join'] .= " LEFT JOIN {$lookup} rhr_pl ON {$wpdb->posts}.ID = rhr_pl.product_id ";
        if ($range[0] !== null) $clauses['where'] .= $wpdb->prepare(' AND rhr_pl.max_price >= %f ', (float) $range[0]);
        if ($range[1] !== null) $clauses['where'] .= $wpdb->prepare(' AND rhr_pl.min_price <= %f ', (float) $range[1]);
        return $clauses;
    }

    /** Also match product SKUs (including variation SKUs) in searches. */
    public static function sku_search($search, $q) {
        if (!$q->get('rhr_wpf_sku') || $search === '') return $search;
        $term = trim((string) $q->get('s'));
        if ($term === '' || strlen($term) > 80) return $search;
        global $wpdb;
        $like = '%' . $wpdb->esc_like($term) . '%';
        $ids  = $wpdb->get_col($wpdb->prepare(
            "SELECT DISTINCT CASE WHEN p.post_parent > 0 THEN p.post_parent ELSE p.ID END FROM {$wpdb->postmeta} pm INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id WHERE pm.meta_key = '_sku' AND pm.meta_value LIKE %s AND p.post_type IN ('product','product_variation') LIMIT 200",
            $like
        ));
        $ids = array_filter(array_map('intval', $ids));
        if (!$ids) return $search;
        // $search looks like " AND ((...))". Turn it into " AND ((...) OR ID IN (...))".
        $search = preg_replace('/^\s*AND\s*/', '', $search, 1);
        return " AND ({$search} OR {$wpdb->posts}.ID IN (" . implode(',', $ids) . ')) ';
    }
}
