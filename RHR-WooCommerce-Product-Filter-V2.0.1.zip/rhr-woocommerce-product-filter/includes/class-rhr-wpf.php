<?php
/**
 * Core: settings, assets, AJAX endpoints and dynamic CSS.
 */
if (!defined('ABSPATH')) exit;

class RHR_WPF {

    /** Keys that are booleans (0/1). */
    const BOOL_KEYS = array(
        'show_search', 'show_categories', 'show_attributes', 'show_price', 'show_stock', 'show_sale',
        'show_rating', 'show_sort', 'show_counts', 'show_reset', 'show_active', 'color_swatches',
        'cat_hierarchy', 'hide_empty', 'collapsible', 'collapsed_default', 'search_sku', 'move_ordering',
        'ajax_archive', 'sticky_desktop', 'shadow', 'auto_archive', 'tablet_drawer',
    );

    /** Integer keys and their allowed range. */
    const INT_KEYS = array(
        'desktop_width'     => array(180, 480),
        'gap'               => array(0, 80),
        'columns'           => array(1, 6),
        'per_page'          => array(1, 60),
        'mobile_breakpoint' => array(480, 1400),
        'tablet_breakpoint' => array(600, 1400),
        'radius'            => array(0, 30),
        'font_size'         => array(11, 20),
        'cat_limit'         => array(0, 100),
        'overlay_opacity'   => array(0, 90),
        'search_min_chars'  => array(1, 5),
    );

    /** Color keys. */
    const COLOR_KEYS = array(
        'accent', 'accent_dark', 'text', 'heading', 'muted', 'border', 'panel', 'input_bg',
        'button_text', 'chip_bg', 'trigger_bg', 'trigger_text', 'overlay',
    );

    /** Select keys and allowed values. */
    const SELECT_KEYS = array(
        'preset'           => array('clean', 'soft', 'minimal', 'bold'),
        'desktop_mode'     => array('sidebar', 'drawer'),
        'mobile_layout'    => array('drawer', 'inline'),
        'drawer_side'      => array('right', 'left', 'bottom'),
        'trigger_position' => array('auto', 'inline', 'floating'),
        'mobile_apply'     => array('button', 'instant'),
        'attribute_style'  => array('chips', 'checkbox'),
        'search_scope'     => array('all', 'current'),
    );

    public static function init() {
        self::maybe_migrate();

        add_shortcode('rhr_product_filter', array(__CLASS__, 'shortcode'));

        // Public, read-only endpoints. No nonce on purpose: page caches serve
        // stale nonces to visitors, which silently broke search in v1.x.
        foreach (array('search', 'grid') as $action) {
            add_action('wp_ajax_rhr_wpf_' . $action, array(__CLASS__, 'ajax_' . $action));
            add_action('wp_ajax_nopriv_rhr_wpf_' . $action, array(__CLASS__, 'ajax_' . $action));
        }

        add_action('wp_enqueue_scripts', array(__CLASS__, 'assets'), 20);
        add_action('woocommerce_before_shop_loop', array(__CLASS__, 'auto_archive_output'), 5);

        // Price bounds cache invalidation.
        add_action('save_post_product', array(__CLASS__, 'flush_bounds'));
        add_action('woocommerce_update_product', array(__CLASS__, 'flush_bounds'));
        add_action('deleted_post', array(__CLASS__, 'flush_bounds'));

        RHR_WPF_Query::init();
        RHR_WPF_Admin::init();
        RHR_WPF_Elementor::init();
    }

    public static function activate() {
        if (!get_option('rhr_wpf_settings')) {
            update_option('rhr_wpf_settings', self::defaults());
            update_option('rhr_wpf_db_version', RHR_WPF_VERSION);
        }
        // Upgrades from 1.x are migrated on the next load by maybe_migrate().
    }

    /**
     * v1.x stored `show_size`. Convert it to the new generic attribute list
     * without touching the user's colors, labels or layout.
     */
    private static function maybe_migrate() {
        $stored = get_option('rhr_wpf_settings');
        if (!is_array($stored) || get_option('rhr_wpf_db_version') === RHR_WPF_VERSION) return;

        if (!isset($stored['attributes'])) {
            $stored['attributes']      = array('size');
            $stored['show_attributes'] = isset($stored['show_size']) ? (int) $stored['show_size'] : 1;
        }
        if (isset($stored['mobile_layout']) && $stored['mobile_layout'] === 'top') {
            $stored['mobile_layout'] = 'inline';
        }
        unset($stored['show_size']);
        update_option('rhr_wpf_settings', $stored);
        update_option('rhr_wpf_db_version', RHR_WPF_VERSION);
    }

    public static function defaults() {
        return array(
            // Filter elements
            'show_search'       => 1,
            'show_categories'   => 1,
            'show_attributes'   => 1,
            'show_price'        => 1,
            'show_stock'        => 0,
            'show_sale'         => 0,
            'show_rating'       => 0,
            'show_sort'         => 1,
            'show_counts'       => 1,
            'show_reset'        => 1,
            'show_active'       => 1,
            'attributes'        => array('size'),
            'attribute_style'   => 'chips',
            'color_swatches'    => 1,
            'cat_hierarchy'     => 1,
            'cat_limit'         => 8,
            'hide_empty'        => 1,
            'collapsible'       => 1,
            'collapsed_default' => 0,
            'search_sku'        => 1,
            'search_min_chars'  => 2,
            'search_scope'      => 'all',

            // Layout
            'desktop_width'     => 280,
            'gap'               => 28,
            'columns'           => 3,
            'per_page'          => 12,
            'mobile_breakpoint' => 767,
            'tablet_drawer'     => 1,
            'tablet_breakpoint' => 1024,
            'desktop_mode'      => 'sidebar',
            'mobile_layout'     => 'drawer',
            'drawer_side'       => 'right',
            'trigger_position'  => 'auto',
            'mobile_apply'      => 'button',
            'move_ordering'     => 1,
            'ajax_archive'      => 1,
            'products_selector' => '',
            'sticky_desktop'    => 1,
            'auto_archive'      => 0,

            // Design
            'preset'            => 'clean',
            'accent'            => '#ff5a6e',
            'accent_dark'       => '#e5405a',
            'text'              => '#1f2430',
            'heading'           => '#111827',
            'muted'             => '#6b7280',
            'border'            => '#e7e9ef',
            'panel'             => '#ffffff',
            'input_bg'          => '#f6f7fa',
            'button_text'       => '#ffffff',
            'chip_bg'           => '#f3f4f7',
            'trigger_bg'        => '#111827',
            'trigger_text'      => '#ffffff',
            'overlay'           => '#0f172a',
            'overlay_opacity'   => 45,
            'radius'            => 10,
            'font_size'         => 14,
            'shadow'            => 1,

            // Labels
            'title'              => 'Filter',
            'drawer_button'      => 'Filters',
            'search_placeholder' => 'Search products...',
            'label_search'       => 'Search',
            'label_sort'         => 'Sort by',
            'label_categories'   => 'Categories',
            'label_price'        => 'Price',
            'label_stock'        => 'Availability',
            'label_in_stock'     => 'In stock only',
            'label_sale'         => 'On sale only',
            'label_rating'       => 'Rating',
            'label_any_rating'   => 'Any rating',
            'label_active'       => 'Active filters',
            'label_reset'        => 'Reset all',
            'label_apply'        => 'Show results',
            'label_show_more'    => 'Show more',
            'label_show_less'    => 'Show less',
            'label_no_results'   => 'No products found.',
            'label_view_all'     => 'See all results for',
        );
    }

    public static function settings() {
        $s = wp_parse_args((array) get_option('rhr_wpf_settings', array()), self::defaults());
        if (!is_array($s['attributes'])) $s['attributes'] = array();
        return $s;
    }

    public static function sanitize_settings($input) {
        $d       = self::defaults();
        $o       = self::settings();
        $input   = is_array($input) ? $input : array();

        foreach ($d as $key => $default) {
            if (!array_key_exists($key, $input)) continue; // Only update submitted tab fields.
            $val = $input[$key];

            if (in_array($key, self::BOOL_KEYS, true)) {
                $o[$key] = empty($val) ? 0 : 1;
            } elseif (isset(self::INT_KEYS[$key])) {
                list($min, $max) = self::INT_KEYS[$key];
                $o[$key] = max($min, min($max, intval($val)));
            } elseif (in_array($key, self::COLOR_KEYS, true)) {
                $c = sanitize_hex_color(is_string($val) ? $val : '');
                $o[$key] = $c ? $c : $o[$key];
            } elseif (isset(self::SELECT_KEYS[$key])) {
                $o[$key] = in_array($val, self::SELECT_KEYS[$key], true) ? $val : $default;
            } elseif ($key === 'attributes') {
                $o[$key] = array_values(array_filter(array_map('sanitize_title', (array) $val)));
            } elseif ($key === 'products_selector') {
                // Allow CSS selector characters only.
                $o[$key] = trim(preg_replace('/[^a-zA-Z0-9_\-\.\#\s,>\[\]="\':]/', '', (string) $val));
            } else {
                $o[$key] = sanitize_text_field((string) $val);
            }
        }
        return $o;
    }

    /* ------------------------------------------------------------------ */
    /* Assets                                                              */
    /* ------------------------------------------------------------------ */

    public static function assets() {
        if (is_admin()) return;
        $s = self::settings();

        wp_register_style('rhr-wpf', RHR_WPF_URL . 'assets/frontend.css', array(), RHR_WPF_VERSION);
        wp_register_script('rhr-wpf', RHR_WPF_URL . 'assets/frontend.js', array(), RHR_WPF_VERSION, true);

        wp_add_inline_style('rhr-wpf', self::dynamic_css($s));
        wp_localize_script('rhr-wpf', 'RHRWPF', array(
            'ajax'             => admin_url('admin-ajax.php'),
            'bp'               => self::breakpoint($s),
            'ajaxArchive'      => (int) $s['ajax_archive'],
            'moveOrdering'     => (int) $s['move_ordering'],
            'productsSelector' => (string) $s['products_selector'],
            'searchMin'        => (int) $s['search_min_chars'],
            'currency'         => function_exists('get_woocommerce_currency_symbol') ? html_entity_decode(get_woocommerce_currency_symbol(), ENT_QUOTES, 'UTF-8') : '',
            'i18n'             => array(
                'search'      => $s['label_search'],
                'price'       => $s['label_price'],
                'rating'      => $s['label_rating'],
                'inStock'     => $s['label_in_stock'],
                'onSale'      => $s['label_sale'],
                'viewAll'     => $s['label_view_all'],
                'noResults'   => $s['label_no_results'],
                'showMore'    => $s['label_show_more'],
                'showLess'    => $s['label_show_less'],
                'loading'     => __('Loading…', 'rhr-woocommerce-product-filter'),
                'searching'   => __('Searching…', 'rhr-woocommerce-product-filter'),
                'error'       => __('Could not load products. Please try again.', 'rhr-woocommerce-product-filter'),
                'andUp'       => __('& up', 'rhr-woocommerce-product-filter'),
            ),
        ));

        // Loaded site-wide in the <head> so the panel is styled before first
        // paint. Late (footer) CSS was the cause of the v1.x mobile drawer
        // "slides in from the left and disappears" flash on category pages.
        wp_enqueue_style('rhr-wpf');
        if (self::should_load_script()) {
            wp_enqueue_script('rhr-wpf');
        }
    }

    private static function should_load_script() {
        if (function_exists('is_woocommerce') && (is_woocommerce() || is_product_taxonomy())) return true;
        if (is_singular()) {
            $post = get_post();
            if ($post && has_shortcode((string) $post->post_content, 'rhr_product_filter')) return true;
        }
        // Elementor pages / templates enqueue it through the widget dependency.
        return (bool) apply_filters('rhr_wpf_load_script', false);
    }

    /** Widest screen that uses the phone-style layout (tablets included when enabled). */
    public static function breakpoint($s) {
        $bp = intval($s['mobile_breakpoint']);
        if (!empty($s['tablet_drawer'])) $bp = max($bp, intval($s['tablet_breakpoint']));
        return $bp;
    }

    public static function hex_to_rgba($hex, $alpha) {
        $hex = ltrim((string) $hex, '#');
        if (strlen($hex) === 3) $hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
        if (strlen($hex) !== 6) return 'rgba(15,23,42,.45)';
        return sprintf('rgba(%d,%d,%d,%s)', hexdec(substr($hex, 0, 2)), hexdec(substr($hex, 2, 2)), hexdec(substr($hex, 4, 2)), round($alpha, 2));
    }

    public static function css_vars($s) {
        return array(
            '--rhr-accent'       => $s['accent'],
            '--rhr-accent-dark'  => $s['accent_dark'],
            '--rhr-text'         => $s['text'],
            '--rhr-heading'      => $s['heading'],
            '--rhr-muted'        => $s['muted'],
            '--rhr-border'       => $s['border'],
            '--rhr-panel'        => $s['panel'],
            '--rhr-input'        => $s['input_bg'],
            '--rhr-btn-text'     => $s['button_text'],
            '--rhr-chip'         => $s['chip_bg'],
            '--rhr-trigger-bg'   => $s['trigger_bg'],
            '--rhr-trigger-text' => $s['trigger_text'],
            '--rhr-overlay'      => self::hex_to_rgba($s['overlay'], $s['overlay_opacity'] / 100),
            '--rhr-radius'       => intval($s['radius']) . 'px',
            '--rhr-fs'           => intval($s['font_size']) . 'px',
            '--rhr-sidebar'      => intval($s['desktop_width']) . 'px',
            '--rhr-gap'          => intval($s['gap']) . 'px',
            '--rhr-cols'         => intval($s['columns']),
        );
    }

    public static function dynamic_css($s) {
        $vars = '';
        foreach (self::css_vars($s) as $k => $v) $vars .= $k . ':' . $v . ';';
        $bp  = self::breakpoint($s);
        $bp1 = $bp + 1;

        $css  = '.rhr-scope{' . $vars . '}';
        if (empty($s['shadow'])) $css .= '.rhr-scope{--rhr-shadow:none;--rhr-shadow-lg:none}';
        // Mobile: hide the in-page panel before JS runs (no flash), show the trigger.
        $css .= '@media (max-width:' . $bp . 'px){'
            . '.rhr-wpf-wrap.rhr-m-drawer:not(.rhr-editor)>.rhr-filter-panel{display:none!important}'
            . '.rhr-wpf-wrap.rhr-m-inline:not(.rhr-inline-open):not(.rhr-editor)>.rhr-filter-panel{display:none}'
            . '.rhr-wpf-wrap.rhr-m-drawer .rhr-trigger,.rhr-wpf-wrap.rhr-m-inline .rhr-trigger{--_d:inline-flex}'
            . '.rhr-wpf-wrap.rhr-grid-mode{display:block}'
            . '.rhr-wpf-wrap .rhr-products-grid ul.products{grid-template-columns:repeat(2,minmax(0,1fr))!important;gap:12px!important}'
            . '}';
        $css .= '@media (min-width:' . $bp1 . 'px){'
            . '.rhr-wpf-wrap.rhr-d-drawer:not(.rhr-editor)>.rhr-filter-panel{display:none!important}'
            . '.rhr-wpf-wrap.rhr-d-drawer .rhr-trigger{--_d:inline-flex}'
            . '.rhr-wpf-wrap.rhr-d-drawer.rhr-grid-mode{display:block}'
            . '}';
        return $css;
    }

    /* ------------------------------------------------------------------ */
    /* Output                                                              */
    /* ------------------------------------------------------------------ */

    public static function shortcode($atts) {
        $atts = shortcode_atts(array(
            'mode'         => 'auto',   // auto | archive | grid
            'category'     => '',       // grid mode: base category slug(s)
            'columns'      => '',
            'per_page'     => '',
            'title'        => '',
            'drawer_side'  => '',
            'trigger'      => '',
            'desktop_mode' => '',
        ), $atts, 'rhr_product_filter');

        $o = array('mode' => $atts['mode'], 'category' => $atts['category'], 'context' => 'shortcode');
        foreach (array('columns', 'per_page', 'title', 'drawer_side', 'desktop_mode') as $k) {
            if ($atts[$k] !== '') $o[$k] = $atts[$k];
        }
        if ($atts['trigger'] !== '') $o['trigger_position'] = $atts['trigger'];
        return RHR_WPF_Render::render($o);
    }

    /** Optional: inject the filter on classic WooCommerce archive templates. */
    public static function auto_archive_output() {
        static $done = false;
        $s = self::settings();
        if ($done || empty($s['auto_archive']) || RHR_WPF_Render::$rendered > 0) return;
        $done = true;
        echo RHR_WPF_Render::render(array('mode' => 'archive', 'desktop_mode' => 'drawer', 'context' => 'auto')); // phpcs:ignore
    }

    /* ------------------------------------------------------------------ */
    /* AJAX                                                                */
    /* ------------------------------------------------------------------ */

    public static function ajax_search() {
        $s    = self::settings();
        $term = isset($_REQUEST['term']) ? sanitize_text_field(wp_unslash($_REQUEST['term'])) : '';
        if (function_exists('mb_strlen') ? mb_strlen($term) < (int) $s['search_min_chars'] : strlen($term) < (int) $s['search_min_chars']) {
            wp_send_json_success(array('items' => array(), 'total' => 0));
        }

        $args = array(
            'post_type'           => 'product',
            'post_status'         => 'publish',
            'posts_per_page'      => 6,
            's'                   => $term,
            'no_found_rows'       => false,
            'ignore_sticky_posts' => true,
            'rhr_wpf_sku'         => !empty($s['search_sku']),
            'tax_query'           => array(self::visibility_clause('search')),
        );
        $cat = isset($_REQUEST['cat']) ? absint($_REQUEST['cat']) : 0;
        if ($cat && $s['search_scope'] === 'current') {
            $args['tax_query'][] = array('taxonomy' => 'product_cat', 'field' => 'term_id', 'terms' => array($cat), 'include_children' => true);
            $args['tax_query']['relation'] = 'AND';
        }
        $q     = new WP_Query($args);
        $items = array();
        foreach ($q->posts as $post) {
            $p = wc_get_product($post);
            if (!$p) continue;
            $items[] = array(
                'title' => html_entity_decode(get_the_title($post), ENT_QUOTES, 'UTF-8'),
                'url'   => get_permalink($post),
                'image' => get_the_post_thumbnail_url($post, 'woocommerce_gallery_thumbnail') ?: wc_placeholder_img_src('woocommerce_gallery_thumbnail'),
                'price' => wp_kses($p->get_price_html(), array('del' => array(), 'ins' => array(), 'span' => array('class' => array()), 'bdi' => array())),
                'stock' => $p->is_in_stock() ? '' : __('Out of stock', 'woocommerce'),
            );
        }
        wp_send_json_success(array('items' => $items, 'total' => (int) $q->found_posts));
    }

    /** Standalone grid mode (shortcode on a normal page). */
    public static function ajax_grid() {
        if (!class_exists('WooCommerce')) wp_send_json_error();
        $raw = array();
        if (isset($_POST['query'])) parse_str(wp_unslash($_POST['query']), $raw); // phpcs:ignore
        $opts = array(
            'paged'    => isset($_POST['paged']) ? max(1, intval($_POST['paged'])) : 1,
            'per_page' => isset($_POST['per_page']) ? max(1, min(60, intval($_POST['per_page']))) : 12,
            'columns'  => isset($_POST['columns']) ? max(1, min(6, intval($_POST['columns']))) : 3,
            'category' => isset($_POST['category']) ? sanitize_text_field(wp_unslash($_POST['category'])) : '',
        );
        $result = RHR_WPF_Render::products(RHR_WPF_Query::normalize($raw), $opts);
        wp_send_json_success($result);
    }

    public static function visibility_clause($context = 'catalog') {
        $terms = array($context === 'search' ? 'exclude-from-search' : 'exclude-from-catalog');
        if ('yes' === get_option('woocommerce_hide_out_of_stock_items')) $terms[] = 'outofstock';
        return array('taxonomy' => 'product_visibility', 'field' => 'name', 'terms' => $terms, 'operator' => 'NOT IN');
    }

    /* ------------------------------------------------------------------ */
    /* Price bounds (uses the WooCommerce lookup table, cached)            */
    /* ------------------------------------------------------------------ */

    public static function price_bounds($term_id = 0) {
        $key   = 'rhr_wpf_bounds_' . intval($term_id);
        $cache = get_transient($key);
        if (is_array($cache)) return $cache;

        global $wpdb;
        $lookup = $wpdb->prefix . 'wc_product_meta_lookup';
        $join   = '';
        $where  = '';
        if ($term_id) {
            $ids = array_merge(array(intval($term_id)), array_map('intval', (array) get_term_children($term_id, 'product_cat')));
            $tt  = $wpdb->get_col("SELECT term_taxonomy_id FROM {$wpdb->term_taxonomy} WHERE taxonomy='product_cat' AND term_id IN (" . implode(',', $ids) . ')'); // phpcs:ignore
            if ($tt) {
                $join  = " INNER JOIN {$wpdb->term_relationships} tr ON tr.object_id = p.ID ";
                $where = ' AND tr.term_taxonomy_id IN (' . implode(',', array_map('intval', $tt)) . ') ';
            }
        }
        $row = $wpdb->get_row("SELECT MIN(l.min_price) AS min_price, MAX(l.max_price) AS max_price FROM {$lookup} l INNER JOIN {$wpdb->posts} p ON p.ID = l.product_id {$join} WHERE p.post_type='product' AND p.post_status='publish' {$where}"); // phpcs:ignore

        if (!$row || $row->max_price === null) {
            // Fallback when the lookup table is missing.
            $row = $wpdb->get_row("SELECT MIN(CAST(pm.meta_value AS DECIMAL(20,4))) AS min_price, MAX(CAST(pm.meta_value AS DECIMAL(20,4))) AS max_price FROM {$wpdb->postmeta} pm INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id WHERE pm.meta_key='_price' AND pm.meta_value <> '' AND p.post_type='product' AND p.post_status='publish'"); // phpcs:ignore
        }
        $min = ($row && $row->min_price !== null) ? (int) floor((float) $row->min_price) : 0;
        $max = ($row && $row->max_price !== null) ? (int) ceil((float) $row->max_price) : 1000;
        if ($max <= $min) $max = $min + 100;

        $bounds = array('min' => $min, 'max' => $max);
        set_transient($key, $bounds, 12 * HOUR_IN_SECONDS);
        $keys = (array) get_option('rhr_wpf_bounds_keys', array());
        if (!in_array($key, $keys, true)) {
            $keys[] = $key;
            update_option('rhr_wpf_bounds_keys', array_slice($keys, -300), false);
        }
        return $bounds;
    }

    public static function flush_bounds() {
        foreach ((array) get_option('rhr_wpf_bounds_keys', array()) as $key) delete_transient($key);
        delete_option('rhr_wpf_bounds_keys');
    }
}
