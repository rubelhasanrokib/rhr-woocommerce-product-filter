<?php
/**
 * Front-end markup for the filter (shortcode, Elementor widget, auto archive).
 */
if (!defined('ABSPATH')) exit;

class RHR_WPF_Render {

    public static $rendered = 0;

    private static $overridable = array(
        'title', 'search_placeholder', 'drawer_button', 'drawer_side', 'trigger_position', 'desktop_mode',
        'mobile_layout', 'mobile_apply', 'attribute_style', 'columns', 'per_page', 'preset', 'collapsible',
        'show_search', 'show_categories', 'show_attributes', 'show_price', 'show_stock', 'show_sale',
        'show_rating', 'show_sort', 'show_counts', 'show_reset', 'show_active', 'cat_limit',
        'label_categories', 'label_price', 'label_apply', 'label_reset',
    );

    public static function icon($name) {
        $icons = array(
            'filter'  => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 6h16M7 12h10M10 18h4" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>',
            'close'   => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>',
            'search'  => '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="11" cy="11" r="7" fill="none" stroke="currentColor" stroke-width="2"/><path d="M20 20l-3.5-3.5" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>',
            'arrow'   => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>',
            'chevron' => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 9l6 6 6-6" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>',
            'plus'    => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 6v12M6 12h12" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>',
            'star'    => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3.5l2.6 5.3 5.9.9-4.3 4.1 1 5.8L12 16.9l-5.2 2.7 1-5.8-4.3-4.1 5.9-.9z" fill="currentColor"/></svg>',
        );
        return isset($icons[$name]) ? $icons[$name] : '';
    }

    private static function is_elementor_editor() {
        if (!did_action('elementor/loaded') || !class_exists('\Elementor\Plugin')) return false;
        $el = \Elementor\Plugin::$instance;
        return (isset($el->editor) && $el->editor->is_edit_mode()) || (isset($el->preview) && $el->preview->is_preview_mode());
    }

    /** Merge dashboard settings with shortcode / widget overrides. */
    public static function config($o) {
        $s = RHR_WPF::settings();
        foreach (self::$overridable as $k) {
            if (!isset($o[$k]) || $o[$k] === '' || $o[$k] === null || $o[$k] === 'inherit') continue;
            $v = $o[$k];
            if (in_array($k, RHR_WPF::BOOL_KEYS, true)) {
                $v = ($v === 'yes' || $v === 'show' || $v === '1' || $v === 1 || $v === true) ? 1 : 0;
            } elseif (isset(RHR_WPF::SELECT_KEYS[$k]) && !in_array($v, RHR_WPF::SELECT_KEYS[$k], true)) {
                continue;
            } elseif (isset(RHR_WPF::INT_KEYS[$k])) {
                list($min, $max) = RHR_WPF::INT_KEYS[$k];
                $v = max($min, min($max, intval($v)));
            } else {
                $v = sanitize_text_field((string) $v);
            }
            $s[$k] = $v;
        }
        return $s;
    }

    public static function render($o = array()) {
        if (!class_exists('WooCommerce')) {
            return current_user_can('manage_options') ? '<p>RHR Product Filter requires WooCommerce.</p>' : '';
        }
        self::$rendered++;
        $s      = self::config($o);
        $editor = self::is_elementor_editor();
        $mode   = isset($o['mode']) ? $o['mode'] : 'auto';
        $archive = $mode === 'archive' || ($mode !== 'grid' && (RHR_WPF_Query::is_product_archive() || $editor));

        wp_enqueue_style('rhr-wpf');
        wp_enqueue_script('rhr-wpf');

        $uid = 'rhr-wpf-' . wp_unique_id();
        $r   = RHR_WPF_Query::request();

        $current_cat = (function_exists('is_product_category') && is_product_category()) ? (int) get_queried_object_id() : 0;
        $grid_cat    = !$archive && !empty($o['category']) ? sanitize_text_field($o['category']) : '';
        $bounds_term = $current_cat;
        if ($grid_cat) {
            $t = get_term_by('slug', strtok($grid_cat, ','), 'product_cat');
            if ($t) $bounds_term = (int) $t->term_id;
        }
        $bounds = RHR_WPF::price_bounds($bounds_term);
        if ($r['cats']) $bounds = RHR_WPF::price_bounds(0);

        $default_orderby = apply_filters('woocommerce_default_catalog_orderby', get_option('woocommerce_default_catalog_orderby', 'menu_order'));

        $cfg = array(
            'mode'    => $archive ? 'archive' : 'grid',
            'mLayout' => $s['mobile_layout'],
            'dMode'   => $s['desktop_mode'],
            'side'    => $s['drawer_side'],
            'trigger' => $s['trigger_position'],
            'apply'   => $s['mobile_apply'],
            'min'     => $bounds['min'],
            'max'     => $bounds['max'],
            'orderby' => $default_orderby,
            'editor'  => $editor ? 1 : 0,
            'cat'     => $current_cat,
            'grid'    => array(
                'columns'  => (int) $s['columns'],
                'per_page' => (int) $s['per_page'],
                'category' => $grid_cat,
            ),
        );

        $classes = array(
            'rhr-wpf-wrap', 'rhr-scope',
            'rhr-preset-' . $s['preset'],
            'rhr-m-' . $s['mobile_layout'],
            'rhr-d-' . $s['desktop_mode'],
            'rhr-side-' . $s['drawer_side'],
            $archive ? 'rhr-archive-mode' : 'rhr-grid-mode',
        );
        if (!empty($s['sticky_desktop'])) $classes[] = 'rhr-sticky';
        if ($editor) $classes[] = 'rhr-editor';
        if (!empty($s['collapsible'])) $classes[] = 'rhr-collapsible';

        $style = '';
        if (!$archive) $style = '--rhr-cols:' . (int) $s['columns'] . ';';

        ob_start();
        ?>
<div id="<?php echo esc_attr($uid); ?>" class="<?php echo esc_attr(implode(' ', $classes)); ?>" data-rhr="<?php echo esc_attr(wp_json_encode($cfg)); ?>"<?php echo $style ? ' style="' . esc_attr($style) . '"' : ''; ?>>
  <button type="button" class="rhr-trigger" aria-expanded="false" aria-controls="<?php echo esc_attr($uid); ?>-panel">
    <span class="rhr-trigger-icon"><?php echo self::icon('filter'); // phpcs:ignore ?></span>
    <span class="rhr-trigger-label"><?php echo esc_html($s['drawer_button']); ?></span>
    <span class="rhr-filter-count" hidden>0</span>
  </button>

  <aside class="rhr-filter-panel" id="<?php echo esc_attr($uid); ?>-panel" aria-label="<?php echo esc_attr($s['title']); ?>">
    <div class="rhr-filter-head">
      <h3 class="rhr-filter-title"><?php echo esc_html($s['title']); ?></h3>
      <?php if ($s['show_reset']) : ?><button type="button" class="rhr-reset rhr-reset-link" hidden><?php echo esc_html($s['label_reset']); ?></button><?php endif; ?>
      <button type="button" class="rhr-close" aria-label="<?php esc_attr_e('Close filters', 'rhr-woocommerce-product-filter'); ?>"><?php echo self::icon('close'); // phpcs:ignore ?></button>
    </div>

    <div class="rhr-panel-body">
      <form class="rhr-filter-form" method="get" action="<?php echo esc_url(self::form_action()); ?>" role="search" novalidate>
        <?php if ($s['show_active']) : ?>
        <div class="rhr-active" hidden>
          <div class="rhr-active-head"><span><?php echo esc_html($s['label_active']); ?></span></div>
          <div class="rhr-active-list"></div>
        </div>
        <?php endif; ?>

        <?php
        if ($s['show_search'])     self::section_search($s, $r);
        if ($s['show_categories']) self::section_categories($s, $r, $current_cat);
        if ($s['show_attributes']) self::section_attributes($s, $r);
        if ($s['show_price'])      self::section_price($s, $r, $bounds);
        if ($s['show_stock'] || $s['show_sale']) self::section_availability($s, $r);
        if ($s['show_rating'])     self::section_rating($s, $r);
        ?>
      </form>
    </div>

    <div class="rhr-panel-foot">
      <?php if ($s['show_reset']) : ?><button type="button" class="rhr-reset rhr-btn rhr-btn-ghost"><?php echo esc_html($s['label_reset']); ?></button><?php endif; ?>
      <button type="button" class="rhr-apply rhr-btn rhr-btn-primary"><?php echo esc_html($s['label_apply']); ?> <span class="rhr-apply-count"></span></button>
    </div>
  </aside>

  <?php if (!$archive) :
      $res = self::products($r, array('paged' => 1, 'per_page' => (int) $s['per_page'], 'columns' => (int) $s['columns'], 'category' => $grid_cat));
      ?>
  <div class="rhr-products-area">
    <div class="rhr-grid-toolbar">
      <span class="rhr-results-count"><?php echo esc_html(self::count_text($res['found'])); ?></span>
      <?php if ($s['show_sort']) self::sort_select($r, $default_orderby); ?>
    </div>
    <div class="rhr-products-grid woocommerce columns-<?php echo (int) $s['columns']; ?>"><?php echo $res['html']; // phpcs:ignore ?></div>
    <nav class="rhr-pagination" aria-label="<?php esc_attr_e('Products pagination', 'rhr-woocommerce-product-filter'); ?>"><?php echo self::pagination_html($res['pages'], 1); // phpcs:ignore ?></nav>
  </div>
  <?php endif; ?>
</div>
        <?php
        return ob_get_clean();
    }

    private static function form_action() {
        if (function_exists('is_product_taxonomy') && is_product_taxonomy()) {
            $link = get_term_link(get_queried_object());
            if (!is_wp_error($link)) return $link;
        }
        if (function_exists('wc_get_page_permalink')) return wc_get_page_permalink('shop');
        return home_url('/');
    }

    private static function section_open($key, $title, $s, $extra_class = '') {
        $collapsed = !empty($s['collapsible']) && !empty($s['collapsed_default']) && $key !== 'search';
        echo '<div class="rhr-sec rhr-sec-' . esc_attr($key) . ($collapsed ? ' is-collapsed' : '') . ($extra_class ? ' ' . esc_attr($extra_class) : '') . '" data-sec="' . esc_attr($key) . '">';
        if ($title !== '') {
            if (!empty($s['collapsible'])) {
                echo '<button type="button" class="rhr-sec-head" aria-expanded="' . ($collapsed ? 'false' : 'true') . '"><span class="rhr-section-title">' . esc_html($title) . '</span><span class="rhr-sec-meta"></span><span class="rhr-chev">' . self::icon('chevron') . '</span></button>'; // phpcs:ignore
            } else {
                echo '<div class="rhr-sec-head is-static"><span class="rhr-section-title">' . esc_html($title) . '</span><span class="rhr-sec-meta"></span></div>';
            }
        }
        echo '<div class="rhr-sec-body">';
    }

    private static function section_close() {
        echo '</div></div>';
    }

    private static function section_search($s, $r) {
        self::section_open('search', $s['label_search'], $s);
        ?>
        <div class="rhr-search">
          <span class="rhr-search-icon"><?php echo self::icon('search'); // phpcs:ignore ?></span>
          <input type="search" name="rhr_s" value="<?php echo esc_attr($r['s']); ?>" placeholder="<?php echo esc_attr($s['search_placeholder']); ?>" autocomplete="off" autocorrect="off" spellcheck="false" enterkeyhint="search" aria-label="<?php echo esc_attr($s['label_search']); ?>" data-label="<?php echo esc_attr($s['label_search']); ?>">
          <button type="button" class="rhr-search-clear" aria-label="<?php esc_attr_e('Clear search', 'rhr-woocommerce-product-filter'); ?>"<?php echo $r['s'] === '' ? ' hidden' : ''; ?>><?php echo self::icon('close'); // phpcs:ignore ?></button>
          <button type="submit" class="rhr-search-go" aria-label="<?php echo esc_attr($s['label_search']); ?>"><?php echo self::icon('arrow'); // phpcs:ignore ?></button>
          <div class="rhr-suggest" role="listbox" hidden></div>
        </div>
        <?php
        self::section_close();
    }

    private static function cat_count($term) {
        $c = get_term_meta($term->term_id, 'product_count_product_cat', true);
        return $c !== '' ? (int) $c : (int) $term->count;
    }

    private static function section_categories($s, $r, $current_cat) {
        $terms = get_terms(array(
            'taxonomy'   => 'product_cat',
            'hide_empty' => (bool) $s['hide_empty'],
            'menu_order' => 'asc',
        ));
        if (is_wp_error($terms) || !$terms) return;

        $default_cat = (int) get_option('default_product_cat');
        $by_parent = array();
        $ids = array();
        foreach ($terms as $t) {
            if ((int) $t->term_id === $default_cat && self::cat_count($t) === 0) continue;
            $ids[(int) $t->term_id] = true;
        }
        foreach ($terms as $t) {
            if (!isset($ids[(int) $t->term_id])) continue;
            $parent = ($s['cat_hierarchy'] && isset($ids[(int) $t->parent])) ? (int) $t->parent : 0;
            $by_parent[$parent][] = $t;
        }
        if (empty($by_parent[0])) return;

        // Ancestors of the current / checked categories are expanded.
        $open = array();
        foreach (array_merge($r['cats'], $current_cat ? array($current_cat) : array()) as $id) {
            foreach (get_ancestors($id, 'product_cat', 'taxonomy') as $a) $open[(int) $a] = true;
        }

        self::section_open('cat', $s['label_categories'], $s);
        echo '<ul class="rhr-terms rhr-cat-tree">';
        self::cat_items($by_parent, 0, $s, $r, $current_cat, $open, 0);
        echo '</ul>';
        $limit = (int) $s['cat_limit'];
        if ($limit > 0 && count($by_parent[0]) > $limit) {
            echo '<button type="button" class="rhr-more" data-more="' . esc_attr($s['label_show_more']) . '" data-less="' . esc_attr($s['label_show_less']) . '">' . esc_html($s['label_show_more']) . ' <span>(' . (count($by_parent[0]) - $limit) . ')</span></button>';
        }
        self::section_close();
    }

    private static function cat_items($by_parent, $parent, $s, $r, $current_cat, $open, $depth) {
        $limit = (int) $s['cat_limit'];
        foreach ($by_parent[$parent] as $i => $t) {
            $id       = (int) $t->term_id;
            $children = !empty($by_parent[$id]);
            $cls      = array('rhr-term');
            if ($id === $current_cat) $cls[] = 'is-current';
            if ($children) $cls[] = 'has-children';
            if ($children && isset($open[$id])) $cls[] = 'is-open';
            if ($depth === 0 && $limit > 0 && $i >= $limit && !in_array($id, $r['cats'], true) && $id !== $current_cat && !isset($open[$id])) $cls[] = 'rhr-extra';
            echo '<li class="' . esc_attr(implode(' ', $cls)) . '">';
            echo '<label class="rhr-check"><input type="checkbox" name="rhr_cat[]" value="' . $id . '" data-label="' . esc_attr($t->name) . '"' . checked(in_array($id, $r['cats'], true), true, false) . '><span class="rhr-box" aria-hidden="true"></span><span class="rhr-term-name">' . esc_html($t->name) . '</span>';
            if ($s['show_counts']) echo '<em class="rhr-count">' . self::cat_count($t) . '</em>';
            echo '</label>';
            if ($children) {
                echo '<button type="button" class="rhr-tree-toggle" aria-expanded="' . (isset($open[$id]) ? 'true' : 'false') . '" aria-label="' . esc_attr(sprintf(__('Show %s subcategories', 'rhr-woocommerce-product-filter'), $t->name)) . '">' . self::icon('chevron') . '</button>'; // phpcs:ignore
                echo '<ul class="rhr-children">';
                self::cat_items($by_parent, $id, $s, $r, $current_cat, $open, $depth + 1);
                echo '</ul>';
            }
            echo '</li>';
        }
    }

    private static function term_color($term) {
        foreach (array('color', 'swatch_color', 'product_attribute_color', 'pa_color', 'rtwpvs_color', 'wvs_color', 'cfvsw_color', 'term_color') as $key) {
            $v = get_term_meta($term->term_id, $key, true);
            if (is_string($v) && sanitize_hex_color($v)) return $v;
        }
        return strtolower(preg_replace('/[^a-zA-Z]/', '', $term->slug));
    }

    private static function section_attributes($s, $r) {
        foreach ((array) $s['attributes'] as $name) {
            $tax = wc_attribute_taxonomy_name($name);
            if (!taxonomy_exists($tax)) continue;
            $terms = get_terms(array('taxonomy' => $tax, 'hide_empty' => true, 'menu_order' => 'asc'));
            if (is_wp_error($terms) || !$terms) continue;
            $label    = wc_attribute_label($tax);
            $is_color = !empty($s['color_swatches']) && preg_match('/colou?r|রং|রঙ/iu', $name . ' ' . $label);
            $style    = $is_color ? 'swatch' : $s['attribute_style'];
            $selected = isset($r['attrs'][$tax]) ? $r['attrs'][$tax] : array();
            $param    = 'rhr_attr_' . sanitize_title($name) . '[]';

            self::section_open('attr-' . sanitize_html_class($name), $label, $s, 'rhr-sec-attr');
            if ($style === 'checkbox') {
                echo '<ul class="rhr-terms">';
                foreach ($terms as $t) {
                    echo '<li class="rhr-term"><label class="rhr-check"><input type="checkbox" name="' . esc_attr($param) . '" value="' . esc_attr($t->slug) . '" data-label="' . esc_attr($label . ': ' . $t->name) . '"' . checked(in_array($t->slug, $selected, true), true, false) . '><span class="rhr-box" aria-hidden="true"></span><span class="rhr-term-name">' . esc_html($t->name) . '</span>';
                    if ($s['show_counts']) echo '<em class="rhr-count">' . (int) $t->count . '</em>';
                    echo '</label></li>';
                }
                echo '</ul>';
            } else {
                echo '<div class="rhr-chips' . ($style === 'swatch' ? ' rhr-swatches' : '') . '">';
                foreach ($terms as $t) {
                    echo '<label class="rhr-chip" title="' . esc_attr($t->name . ($s['show_counts'] ? ' (' . (int) $t->count . ')' : '')) . '"><input type="checkbox" name="' . esc_attr($param) . '" value="' . esc_attr($t->slug) . '" data-label="' . esc_attr($label . ': ' . $t->name) . '"' . checked(in_array($t->slug, $selected, true), true, false) . '><span class="rhr-chip-inner">';
                    if ($style === 'swatch') echo '<i class="rhr-dot" data-color="' . esc_attr(self::term_color($t)) . '"></i>';
                    echo '<span class="rhr-chip-name">' . esc_html($t->name) . '</span>';
                    if ($s['show_counts'] && $style !== 'swatch') echo '<em class="rhr-count">' . (int) $t->count . '</em>';
                    echo '</span></label>';
                }
                echo '</div>';
            }
            self::section_close();
        }
    }

    private static function section_price($s, $r, $bounds) {
        $cur = function_exists('get_woocommerce_currency_symbol') ? get_woocommerce_currency_symbol() : '';
        $min = $r['min'] !== null ? $r['min'] : '';
        $max = $r['max'] !== null ? $r['max'] : '';
        $step = ($bounds['max'] - $bounds['min']) > 2000 ? 10 : 1;
        self::section_open('price', $s['label_price'], $s);
        ?>
        <div class="rhr-price" data-min="<?php echo esc_attr($bounds['min']); ?>" data-max="<?php echo esc_attr($bounds['max']); ?>">
          <div class="rhr-range">
            <div class="rhr-range-track"><div class="rhr-range-fill"></div></div>
            <input type="range" class="rhr-range-min" min="<?php echo esc_attr($bounds['min']); ?>" max="<?php echo esc_attr($bounds['max']); ?>" step="<?php echo (int) $step; ?>" value="<?php echo esc_attr($min !== '' ? $min : $bounds['min']); ?>" aria-label="<?php esc_attr_e('Minimum price', 'rhr-woocommerce-product-filter'); ?>">
            <input type="range" class="rhr-range-max" min="<?php echo esc_attr($bounds['min']); ?>" max="<?php echo esc_attr($bounds['max']); ?>" step="<?php echo (int) $step; ?>" value="<?php echo esc_attr($max !== '' ? $max : $bounds['max']); ?>" aria-label="<?php esc_attr_e('Maximum price', 'rhr-woocommerce-product-filter'); ?>">
          </div>
          <div class="rhr-price-inputs">
            <label><span class="rhr-cur"><?php echo wp_kses_post($cur); ?></span><input type="number" inputmode="numeric" name="rhr_min_price" min="0" value="<?php echo esc_attr($min); ?>" placeholder="<?php echo esc_attr($bounds['min']); ?>" aria-label="<?php esc_attr_e('Minimum price', 'rhr-woocommerce-product-filter'); ?>"></label>
            <span class="rhr-dash">–</span>
            <label><span class="rhr-cur"><?php echo wp_kses_post($cur); ?></span><input type="number" inputmode="numeric" name="rhr_max_price" min="0" value="<?php echo esc_attr($max); ?>" placeholder="<?php echo esc_attr($bounds['max']); ?>" aria-label="<?php esc_attr_e('Maximum price', 'rhr-woocommerce-product-filter'); ?>"></label>
          </div>
        </div>
        <?php
        self::section_close();
    }

    private static function section_availability($s, $r) {
        self::section_open('stock', $s['label_stock'], $s);
        if ($s['show_stock']) {
            echo '<label class="rhr-switch"><input type="checkbox" name="rhr_stock" value="1" data-label="' . esc_attr($s['label_in_stock']) . '"' . checked($r['stock'], true, false) . '><span class="rhr-switch-ui" aria-hidden="true"></span><span>' . esc_html($s['label_in_stock']) . '</span></label>';
        }
        if ($s['show_sale']) {
            echo '<label class="rhr-switch"><input type="checkbox" name="rhr_sale" value="1" data-label="' . esc_attr($s['label_sale']) . '"' . checked($r['sale'], true, false) . '><span class="rhr-switch-ui" aria-hidden="true"></span><span>' . esc_html($s['label_sale']) . '</span></label>';
        }
        self::section_close();
    }

    private static function section_rating($s, $r) {
        self::section_open('rating', $s['label_rating'], $s);
        echo '<div class="rhr-ratings">';
        echo '<label class="rhr-radio"><input type="radio" name="rhr_rating" value=""' . checked($r['rating'], 0, false) . '><span class="rhr-radio-ui" aria-hidden="true"></span><span>' . esc_html($s['label_any_rating']) . '</span></label>';
        foreach (array(4, 3, 2, 1) as $n) {
            echo '<label class="rhr-radio"><input type="radio" name="rhr_rating" value="' . $n . '" data-label="' . esc_attr($n . '★ ' . __('& up', 'rhr-woocommerce-product-filter')) . '"' . checked($r['rating'], $n, false) . '><span class="rhr-radio-ui" aria-hidden="true"></span><span class="rhr-stars" aria-label="' . esc_attr(sprintf(__('%d stars & up', 'rhr-woocommerce-product-filter'), $n)) . '">';
            for ($i = 1; $i <= 5; $i++) echo '<i class="' . ($i <= $n ? 'on' : '') . '">' . self::icon('star') . '</i>'; // phpcs:ignore
            echo '</span><small>' . esc_html__('& up', 'rhr-woocommerce-product-filter') . '</small></label>';
        }
        echo '</div>';
        self::section_close();
    }

    private static function sort_select($r, $default) {
        $options = array(
            'menu_order' => __('Default sorting', 'woocommerce'),
            'popularity' => __('Sort by popularity', 'woocommerce'),
            'rating'     => __('Sort by average rating', 'woocommerce'),
            'date'       => __('Sort by latest', 'woocommerce'),
            'price'      => __('Sort by price: low to high', 'woocommerce'),
            'price-desc' => __('Sort by price: high to low', 'woocommerce'),
        );
        if ('no' === get_option('woocommerce_enable_review_rating')) unset($options['rating']);
        $options = apply_filters('woocommerce_catalog_orderby', $options);
        $current = $r['orderby'] ? $r['orderby'] : $default;
        echo '<select class="rhr-sort" name="orderby" aria-label="' . esc_attr__('Sort products', 'rhr-woocommerce-product-filter') . '">';
        foreach ($options as $k => $label) echo '<option value="' . esc_attr($k) . '"' . selected($current, $k, false) . '>' . esc_html($label) . '</option>';
        echo '</select>';
    }

    public static function count_text($n) {
        /* translators: %d: number of products */
        return sprintf(_n('%d product', '%d products', (int) $n, 'rhr-woocommerce-product-filter'), (int) $n);
    }

    public static function pagination_html($pages, $current) {
        $pages = (int) $pages;
        if ($pages <= 1) return '';
        $out = '';
        $range = array();
        for ($i = 1; $i <= $pages; $i++) {
            if ($i === 1 || $i === $pages || abs($i - $current) <= 1) $range[] = $i;
        }
        $prev = 0;
        if ($current > 1) $out .= '<button type="button" class="rhr-page rhr-page-prev" data-page="' . ($current - 1) . '" aria-label="Previous">‹</button>';
        foreach ($range as $i) {
            if ($prev && $i - $prev > 1) $out .= '<span class="rhr-page-gap">…</span>';
            $out .= '<button type="button" class="rhr-page' . ($i === (int) $current ? ' is-active' : '') . '" data-page="' . $i . '"' . ($i === (int) $current ? ' aria-current="page"' : '') . '>' . $i . '</button>';
            $prev = $i;
        }
        if ($current < $pages) $out .= '<button type="button" class="rhr-page rhr-page-next" data-page="' . ($current + 1) . '" aria-label="Next">›</button>';
        return $out;
    }

    /** Product grid for standalone (non-archive) pages. */
    public static function products($r, $opts) {
        $s        = RHR_WPF::settings();
        $paged    = max(1, (int) $opts['paged']);
        $per_page = max(1, (int) $opts['per_page']);
        $columns  = max(1, min(6, (int) $opts['columns']));

        $args = array(
            'post_type'           => 'product',
            'post_status'         => 'publish',
            'posts_per_page'      => $per_page,
            'paged'               => $paged,
            'ignore_sticky_posts' => true,
            'tax_query'           => array(RHR_WPF::visibility_clause('catalog')),
            'meta_query'          => array(),
            'rhr_wpf_request'     => $r,
        );
        if (!empty($opts['category']) && !$r['cats']) {
            $args['tax_query'][] = array('taxonomy' => 'product_cat', 'field' => 'slug', 'terms' => array_map('sanitize_title', explode(',', $opts['category'])), 'operator' => 'IN');
        }

        $wc_query = (function_exists('WC') && WC()->query) ? WC()->query : null;
        $orderby  = $r['orderby'] ? $r['orderby'] : apply_filters('woocommerce_default_catalog_orderby', get_option('woocommerce_default_catalog_orderby', 'menu_order'));
        if ($wc_query) {
            $ord = $wc_query->get_catalog_ordering_args($orderby, '');
            $args['orderby'] = $ord['orderby'];
            $args['order']   = $ord['order'];
            if (!empty($ord['meta_key'])) $args['meta_key'] = $ord['meta_key'];
        } else {
            $args['orderby'] = 'date';
            $args['order']   = 'DESC';
        }

        $q = new WP_Query($args);
        if ($wc_query) $wc_query->remove_ordering_args();

        ob_start();
        if ($q->have_posts()) {
            wc_setup_loop(array(
                'name'         => 'rhr_wpf',
                'columns'      => $columns,
                'is_shortcode' => true,
                'is_paginated' => true,
                'total'        => $q->found_posts,
                'total_pages'  => $q->max_num_pages,
                'per_page'     => $per_page,
                'current_page' => $paged,
            ));
            woocommerce_product_loop_start();
            while ($q->have_posts()) {
                $q->the_post();
                wc_get_template_part('content', 'product');
            }
            woocommerce_product_loop_end();
            wc_reset_loop();
        } else {
            echo '<p class="woocommerce-info rhr-no-products">' . esc_html($s['label_no_results']) . '</p>';
        }
        wp_reset_postdata();
        $html = ob_get_clean();

        return array(
            'html'  => $html,
            'found' => (int) $q->found_posts,
            'pages' => (int) $q->max_num_pages,
            'paged' => $paged,
            'count' => self::count_text($q->found_posts),
            'pagination' => self::pagination_html($q->max_num_pages, $paged),
        );
    }
}
