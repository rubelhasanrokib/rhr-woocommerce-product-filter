<?php
/**
 * Elementor widget: RHR Product Filter.
 * Every option defaults to "Dashboard" so the global settings stay the source
 * of truth; anything set here overrides them for this widget only.
 */
if (!defined('ABSPATH')) exit;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

class RHR_WPF_Elementor_Widget extends \Elementor\Widget_Base {

    public function get_name() { return 'rhr-product-filter'; }
    public function get_title() { return 'RHR Product Filter'; }
    public function get_icon() { return 'eicon-filter'; }
    public function get_categories() { return array('rhr-elements', 'woocommerce-elements'); }
    public function get_keywords() { return array('filter', 'product', 'woocommerce', 'shop', 'category', 'search', 'price', 'rhr'); }
    public function get_style_depends() { return array('rhr-wpf'); }
    public function get_script_depends() { return array('rhr-wpf'); }

    private function inherit_select($id, $label, $options) {
        $this->add_control($id, array(
            'label'   => $label,
            'type'    => Controls_Manager::SELECT,
            'default' => 'inherit',
            'options' => array('inherit' => __('Dashboard default', 'rhr-woocommerce-product-filter')) + $options,
        ));
    }

    private function var_color($id, $label, $var) {
        $this->add_control($id, array(
            'label'     => $label,
            'type'      => Controls_Manager::COLOR,
            'selectors' => array('{{WRAPPER}} .rhr-scope' => $var . ': {{VALUE}};'),
        ));
    }

    protected function register_controls() {
        $showhide = array('yes' => __('Show', 'rhr-woocommerce-product-filter'), 'no' => __('Hide', 'rhr-woocommerce-product-filter'));

        /* ---------------- Content ---------------- */
        $this->start_controls_section('sec_general', array('label' => __('Filter', 'rhr-woocommerce-product-filter')));
        $this->add_control('info', array(
            'type' => Controls_Manager::RAW_HTML,
            'raw'  => '<div style="line-height:1.5">' . sprintf(
                /* translators: %s: dashboard link */
                __('Place this widget next to the <b>Archive Products</b> / Loop Grid widget in your Product Archive template. Global defaults & colors: <a href="%s" target="_blank">RHR Filter dashboard</a>.', 'rhr-woocommerce-product-filter'),
                esc_url(admin_url('admin.php?page=rhr-wpf&tab=design'))
            ) . '</div>',
            'content_classes' => 'elementor-panel-alert elementor-panel-alert-info',
        ));
        $this->add_control('mode', array(
            'label'   => __('Mode', 'rhr-woocommerce-product-filter'),
            'type'    => Controls_Manager::SELECT,
            'default' => 'auto',
            'options' => array(
                'auto'    => __('Auto (recommended)', 'rhr-woocommerce-product-filter'),
                'archive' => __('Filter the page’s product grid', 'rhr-woocommerce-product-filter'),
                'grid'    => __('Show its own product grid', 'rhr-woocommerce-product-filter'),
            ),
            'description' => __('Auto: on shop/category pages it filters the Archive Products widget; on normal pages it shows its own grid.', 'rhr-woocommerce-product-filter'),
        ));
        $this->add_control('title', array('label' => __('Title', 'rhr-woocommerce-product-filter'), 'type' => Controls_Manager::TEXT, 'placeholder' => __('Dashboard default', 'rhr-woocommerce-product-filter')));
        $this->add_control('search_placeholder', array('label' => __('Search placeholder', 'rhr-woocommerce-product-filter'), 'type' => Controls_Manager::TEXT, 'placeholder' => __('Dashboard default', 'rhr-woocommerce-product-filter')));
        $this->add_control('drawer_button', array('label' => __('Mobile “Filters” button text', 'rhr-woocommerce-product-filter'), 'type' => Controls_Manager::TEXT, 'placeholder' => __('Dashboard default', 'rhr-woocommerce-product-filter')));
        $this->add_control('label_apply', array('label' => __('“Show results” button text', 'rhr-woocommerce-product-filter'), 'type' => Controls_Manager::TEXT, 'placeholder' => __('Dashboard default', 'rhr-woocommerce-product-filter')));
        $this->add_control('category', array('label' => __('Limit grid to category slugs', 'rhr-woocommerce-product-filter'), 'type' => Controls_Manager::TEXT, 'placeholder' => 'three-piece,kids-item', 'condition' => array('mode' => 'grid')));
        $this->add_control('columns', array('label' => __('Grid columns', 'rhr-woocommerce-product-filter'), 'type' => Controls_Manager::NUMBER, 'min' => 1, 'max' => 6, 'condition' => array('mode' => 'grid')));
        $this->add_control('per_page', array('label' => __('Products per page', 'rhr-woocommerce-product-filter'), 'type' => Controls_Manager::NUMBER, 'min' => 1, 'max' => 60, 'condition' => array('mode' => 'grid')));
        $this->end_controls_section();

        $this->start_controls_section('sec_sections', array('label' => __('Show / hide sections', 'rhr-woocommerce-product-filter')));
        $this->inherit_select('show_search', __('Search', 'rhr-woocommerce-product-filter'), $showhide);
        $this->inherit_select('show_categories', __('Categories', 'rhr-woocommerce-product-filter'), $showhide);
        $this->inherit_select('show_attributes', __('Attributes', 'rhr-woocommerce-product-filter'), $showhide);
        $this->inherit_select('show_price', __('Price', 'rhr-woocommerce-product-filter'), $showhide);
        $this->inherit_select('show_stock', __('In stock', 'rhr-woocommerce-product-filter'), $showhide);
        $this->inherit_select('show_sale', __('On sale', 'rhr-woocommerce-product-filter'), $showhide);
        $this->inherit_select('show_rating', __('Rating', 'rhr-woocommerce-product-filter'), $showhide);
        $this->inherit_select('show_active', __('Active filter chips', 'rhr-woocommerce-product-filter'), $showhide);
        $this->inherit_select('show_counts', __('Product counts', 'rhr-woocommerce-product-filter'), $showhide);
        $this->inherit_select('collapsible', __('Collapsible sections', 'rhr-woocommerce-product-filter'), array('yes' => __('Yes', 'rhr-woocommerce-product-filter'), 'no' => __('No', 'rhr-woocommerce-product-filter')));
        $this->inherit_select('attribute_style', __('Attribute style', 'rhr-woocommerce-product-filter'), array('chips' => __('Chips', 'rhr-woocommerce-product-filter'), 'checkbox' => __('Checkbox list', 'rhr-woocommerce-product-filter')));
        $this->end_controls_section();

        $this->start_controls_section('sec_mobile', array('label' => __('Mobile & drawer', 'rhr-woocommerce-product-filter')));
        $this->inherit_select('mobile_layout', __('Mobile style', 'rhr-woocommerce-product-filter'), array('drawer' => __('Slide-in drawer', 'rhr-woocommerce-product-filter'), 'inline' => __('Expand in place', 'rhr-woocommerce-product-filter')));
        $this->inherit_select('drawer_side', __('Drawer opens from', 'rhr-woocommerce-product-filter'), array('right' => __('Right', 'rhr-woocommerce-product-filter'), 'left' => __('Left', 'rhr-woocommerce-product-filter'), 'bottom' => __('Bottom sheet', 'rhr-woocommerce-product-filter')));
        $this->inherit_select('trigger_position', __('Filter button position', 'rhr-woocommerce-product-filter'), array('auto' => __('Above product grid', 'rhr-woocommerce-product-filter'), 'inline' => __('Here (widget position)', 'rhr-woocommerce-product-filter'), 'floating' => __('Floating bottom', 'rhr-woocommerce-product-filter')));
        $this->inherit_select('mobile_apply', __('Apply changes', 'rhr-woocommerce-product-filter'), array('button' => __('On “Show results”', 'rhr-woocommerce-product-filter'), 'instant' => __('Instantly', 'rhr-woocommerce-product-filter')));
        $this->inherit_select('desktop_mode', __('Desktop style', 'rhr-woocommerce-product-filter'), array('sidebar' => __('Sidebar', 'rhr-woocommerce-product-filter'), 'drawer' => __('Button + drawer', 'rhr-woocommerce-product-filter')));
        $this->end_controls_section();

        /* ---------------- Style: colors ---------------- */
        $this->start_controls_section('st_colors', array('label' => __('Colors', 'rhr-woocommerce-product-filter'), 'tab' => Controls_Manager::TAB_STYLE));
        $this->add_control('colors_note', array('type' => Controls_Manager::RAW_HTML, 'raw' => __('Empty = dashboard color. Set a color to override it for this widget.', 'rhr-woocommerce-product-filter'), 'content_classes' => 'elementor-descriptor'));
        $this->add_control('h_brand', array('label' => __('Brand', 'rhr-woocommerce-product-filter'), 'type' => Controls_Manager::HEADING, 'separator' => 'before'));
        $this->var_color('c_accent', __('Accent', 'rhr-woocommerce-product-filter'), '--rhr-accent');
        $this->var_color('c_accent_dark', __('Accent hover', 'rhr-woocommerce-product-filter'), '--rhr-accent-dark');
        $this->var_color('c_btn_text', __('Text on accent', 'rhr-woocommerce-product-filter'), '--rhr-btn-text');
        $this->add_control('h_text', array('label' => __('Text', 'rhr-woocommerce-product-filter'), 'type' => Controls_Manager::HEADING, 'separator' => 'before'));
        $this->var_color('c_heading', __('Headings', 'rhr-woocommerce-product-filter'), '--rhr-heading');
        $this->var_color('c_text', __('Body text', 'rhr-woocommerce-product-filter'), '--rhr-text');
        $this->var_color('c_muted', __('Muted text', 'rhr-woocommerce-product-filter'), '--rhr-muted');
        $this->add_control('h_surface', array('label' => __('Surfaces', 'rhr-woocommerce-product-filter'), 'type' => Controls_Manager::HEADING, 'separator' => 'before'));
        $this->var_color('c_panel', __('Panel background', 'rhr-woocommerce-product-filter'), '--rhr-panel');
        $this->var_color('c_input', __('Input background', 'rhr-woocommerce-product-filter'), '--rhr-input');
        $this->var_color('c_chip', __('Chips / badges', 'rhr-woocommerce-product-filter'), '--rhr-chip');
        $this->var_color('c_border', __('Borders', 'rhr-woocommerce-product-filter'), '--rhr-border');
        $this->add_control('h_trigger', array('label' => __('Mobile Filter button', 'rhr-woocommerce-product-filter'), 'type' => Controls_Manager::HEADING, 'separator' => 'before'));
        $this->var_color('c_trigger_bg', __('Button background', 'rhr-woocommerce-product-filter'), '--rhr-trigger-bg');
        $this->var_color('c_trigger_text', __('Button text', 'rhr-woocommerce-product-filter'), '--rhr-trigger-text');
        $this->var_color('c_overlay', __('Drawer overlay (use transparency)', 'rhr-woocommerce-product-filter'), '--rhr-overlay');
        $this->end_controls_section();

        /* ---------------- Style: panel ---------------- */
        $this->start_controls_section('st_panel', array('label' => __('Panel', 'rhr-woocommerce-product-filter'), 'tab' => Controls_Manager::TAB_STYLE));
        $this->add_responsive_control('panel_padding', array(
            'label'      => __('Padding', 'rhr-woocommerce-product-filter'),
            'type'       => Controls_Manager::DIMENSIONS,
            'size_units' => array('px', 'em'),
            'selectors'  => array('{{WRAPPER}} .rhr-wpf-wrap > .rhr-filter-panel' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'),
        ));
        $this->add_control('radius', array(
            'label'      => __('Corner radius', 'rhr-woocommerce-product-filter'),
            'type'       => Controls_Manager::SLIDER,
            'size_units' => array('px'),
            'range'      => array('px' => array('min' => 0, 'max' => 30)),
            'selectors'  => array('{{WRAPPER}} .rhr-scope' => '--rhr-radius: {{SIZE}}px;'),
        ));
        $this->add_group_control(Group_Control_Border::get_type(), array('name' => 'panel_border', 'selector' => '{{WRAPPER}} .rhr-wpf-wrap > .rhr-filter-panel'));
        $this->add_group_control(Group_Control_Box_Shadow::get_type(), array('name' => 'panel_shadow', 'selector' => '{{WRAPPER}} .rhr-wpf-wrap > .rhr-filter-panel'));
        $this->add_responsive_control('section_space', array(
            'label'     => __('Space between sections', 'rhr-woocommerce-product-filter'),
            'type'      => Controls_Manager::SLIDER,
            'range'     => array('px' => array('min' => 0, 'max' => 40)),
            'selectors' => array('{{WRAPPER}} .rhr-sec' => 'padding-top: {{SIZE}}px; padding-bottom: {{SIZE}}px;'),
        ));
        $this->add_control('sticky_top', array(
            'label'     => __('Sticky offset from top', 'rhr-woocommerce-product-filter'),
            'type'      => Controls_Manager::SLIDER,
            'range'     => array('px' => array('min' => 0, 'max' => 200)),
            'selectors' => array('{{WRAPPER}} .rhr-scope' => '--rhr-sticky-top: {{SIZE}}px;'),
            'description' => __('Useful with a sticky header.', 'rhr-woocommerce-product-filter'),
        ));
        $this->end_controls_section();

        /* ---------------- Style: typography ---------------- */
        $this->start_controls_section('st_type', array('label' => __('Typography', 'rhr-woocommerce-product-filter'), 'tab' => Controls_Manager::TAB_STYLE));
        $this->add_responsive_control('base_size', array(
            'label'     => __('Base size', 'rhr-woocommerce-product-filter'),
            'type'      => Controls_Manager::SLIDER,
            'range'     => array('px' => array('min' => 11, 'max' => 20)),
            'selectors' => array('{{WRAPPER}} .rhr-scope' => '--rhr-fs: {{SIZE}}px;'),
        ));
        $this->add_group_control(Group_Control_Typography::get_type(), array('name' => 'ty_title', 'label' => __('Title', 'rhr-woocommerce-product-filter'), 'selector' => '{{WRAPPER}} .rhr-filter-title'));
        $this->add_group_control(Group_Control_Typography::get_type(), array('name' => 'ty_section', 'label' => __('Section titles', 'rhr-woocommerce-product-filter'), 'selector' => '{{WRAPPER}} .rhr-section-title'));
        $this->add_group_control(Group_Control_Typography::get_type(), array('name' => 'ty_option', 'label' => __('Options', 'rhr-woocommerce-product-filter'), 'selector' => '{{WRAPPER}} .rhr-term-name, {{WRAPPER}} .rhr-chip-name, {{WRAPPER}} .rhr-switch > span:last-child'));
        $this->add_group_control(Group_Control_Typography::get_type(), array('name' => 'ty_trigger', 'label' => __('Filter button', 'rhr-woocommerce-product-filter'), 'selector' => '{{WRAPPER}} .rhr-trigger-label'));
        $this->end_controls_section();

        /* ---------------- Style: filter button ---------------- */
        $this->start_controls_section('st_trigger', array('label' => __('Mobile Filter button', 'rhr-woocommerce-product-filter'), 'tab' => Controls_Manager::TAB_STYLE));
        $this->add_control('trigger_height', array(
            'label'     => __('Height', 'rhr-woocommerce-product-filter'),
            'type'      => Controls_Manager::SLIDER,
            'range'     => array('px' => array('min' => 32, 'max' => 64)),
            'selectors' => array('{{WRAPPER}} .rhr-scope button.rhr-trigger' => '--_h: {{SIZE}}px;'),
        ));
        $this->add_control('trigger_radius', array(
            'label'     => __('Corner radius', 'rhr-woocommerce-product-filter'),
            'type'      => Controls_Manager::SLIDER,
            'range'     => array('px' => array('min' => 0, 'max' => 40)),
            'selectors' => array('{{WRAPPER}} .rhr-scope button.rhr-trigger' => '--_rd: {{SIZE}}px;'),
        ));
        $this->add_control('trigger_full', array(
            'label'        => __('Full width (inline position)', 'rhr-woocommerce-product-filter'),
            'type'         => Controls_Manager::SWITCHER,
            'return_value' => 'yes',
            'selectors'    => array('{{WRAPPER}} .rhr-wpf-wrap > button.rhr-trigger' => '--_w: 100%;'),
        ));
        $this->end_controls_section();
    }

    protected function render() {
        $st = $this->get_settings_for_display();
        $o  = array('context' => 'elementor', 'mode' => isset($st['mode']) ? $st['mode'] : 'auto');
        $keys = array(
            'title', 'search_placeholder', 'drawer_button', 'label_apply', 'category', 'columns', 'per_page',
            'show_search', 'show_categories', 'show_attributes', 'show_price', 'show_stock', 'show_sale', 'show_rating',
            'show_active', 'show_counts', 'collapsible', 'attribute_style', 'mobile_layout', 'drawer_side',
            'trigger_position', 'mobile_apply', 'desktop_mode',
        );
        foreach ($keys as $k) {
            if (isset($st[$k]) && $st[$k] !== '' && $st[$k] !== 'inherit') $o[$k] = $st[$k];
        }
        echo RHR_WPF_Render::render($o); // phpcs:ignore -- escaped in renderer
    }
}
