<?php
/**
 * Elementor integration: registers the "RHR Product Filter" widget.
 */
if (!defined('ABSPATH')) exit;

class RHR_WPF_Elementor {

    public static function init() {
        add_action('elementor/elements/categories_registered', array(__CLASS__, 'category'));
        add_action('elementor/widgets/register', array(__CLASS__, 'register'));
    }

    public static function category($manager) {
        $manager->add_category('rhr-elements', array('title' => 'RHR Elements', 'icon' => 'eicon-filter'));
    }

    public static function register($widgets_manager) {
        if (!class_exists('\Elementor\Widget_Base')) return;
        require_once RHR_WPF_PATH . 'includes/elementor/class-rhr-wpf-widget.php';
        $widgets_manager->register(new RHR_WPF_Elementor_Widget());
    }
}
