/* RHR Product Filter – dashboard */
jQuery(function ($) {
  'use strict';
  var preview = document.querySelectorAll('.rhr-preview-frame');
  var varMap = {
    accent: '--rhr-accent', accent_dark: '--rhr-accent-dark', text: '--rhr-text', heading: '--rhr-heading',
    muted: '--rhr-muted', border: '--rhr-border', panel: '--rhr-panel', input_bg: '--rhr-input',
    button_text: '--rhr-btn-text', chip_bg: '--rhr-chip', trigger_bg: '--rhr-trigger-bg', trigger_text: '--rhr-trigger-text'
  };

  function rgba(hex, a) {
    hex = String(hex || '').replace('#', '');
    if (hex.length === 3) hex = hex.replace(/(.)/g, '$1$1');
    if (hex.length !== 6) return 'rgba(15,23,42,.45)';
    return 'rgba(' + parseInt(hex.substr(0, 2), 16) + ',' + parseInt(hex.substr(2, 2), 16) + ',' + parseInt(hex.substr(4, 2), 16) + ',' + a + ')';
  }

  function setVar(key, val) {
    if (!varMap[key] || !val) return;
    preview.forEach(function (p) {
      p.style.setProperty(varMap[key], val);
      if (key === 'accent') {
        p.style.setProperty('--rhr-soft', 'color-mix(in srgb,' + val + ' 11%, var(--rhr-panel))');
        p.style.setProperty('--rhr-soft-2', 'color-mix(in srgb,' + val + ' 22%, var(--rhr-panel))');
      }
    });
  }

  $('.rhr-color-input').each(function () {
    var $i = $(this), key = $i.data('key');
    $i.wpColorPicker({
      change: function (e, ui) { setVar(key, ui.color.toString()); },
      clear: function () { setVar(key, $i.data('default-color')); }
    });
  });

  // One-click palettes.
  $('.rhr-palette').on('click', function () {
    var colors = $(this).data('colors') || {};
    $('.rhr-palette').removeClass('is-picked');
    $(this).addClass('is-picked');
    Object.keys(colors).forEach(function (k) {
      var $i = $('.rhr-color-input[data-key="' + k + '"]');
      if ($i.length) { $i.wpColorPicker('color', colors[k]); }
      setVar(k, colors[k]);
    });
  });

  // Number fields that affect the preview.
  $('input[data-var="radius"]').on('input', function () { preview.forEach(function (p) { p.style.setProperty('--rhr-radius', (parseInt(this.value, 10) || 0) + 'px'); }, this); });
  $('input[data-var="font_size"]').on('input', function () { preview.forEach(function (p) { p.style.setProperty('--rhr-fs', (parseInt(this.value, 10) || 14) + 'px'); }, this); });

  // Presets.
  $('.rhr-preset-card input').on('change', function () {
    var v = this.value;
    $('.rhr-preset-card').removeClass('selected');
    $(this).closest('.rhr-preset-card').addClass('selected');
    preview.forEach(function (p) { p.className = p.className.replace(/rhr-preset-\S+/, 'rhr-preset-' + v); });
  });

  // Copy buttons.
  $(document).on('click', '.rhr-copy', function () {
    var $b = $(this), text = $b.data('copy');
    var done = function () { var t = $b.text(); $b.text('Copied!'); setTimeout(function () { $b.text(t); }, 1400); };
    if (navigator.clipboard) navigator.clipboard.writeText(text).then(done);
    else { var ta = $('<textarea>').val(text).appendTo('body').select(); document.execCommand('copy'); ta.remove(); done(); }
  });

  // Warn about unsaved changes.
  var dirty = false;
  $('#rhr-wpf-settings-form').on('change input', function () { dirty = true; }).on('submit', function () { dirty = false; });
  $('.rhr-palette').on('click', function () { dirty = true; });
  $(window).on('beforeunload', function () { if (dirty) return true; });
});
