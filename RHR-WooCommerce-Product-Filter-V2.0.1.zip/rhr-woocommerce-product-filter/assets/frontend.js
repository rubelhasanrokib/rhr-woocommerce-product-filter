/*!
 * RHR WooCommerce Product Filter – frontend
 * Version 2.0.1 · Rubel Hasan Rokib
 */
(function () {
  'use strict';

  var G = window.RHRWPF || {};
  var T = G.i18n || {};
  var BP = parseInt(G.bp, 10) || 767;
  var mq = window.matchMedia('(max-width:' + BP + 'px)');
  var instances = [];
  var bar = null;          // shared mobile toolbar (Filter button + sort)
  var navCtl = null;       // AbortController for archive refreshes
  var globalsBound = false;

  var VARS = ['--rhr-accent', '--rhr-accent-dark', '--rhr-text', '--rhr-heading', '--rhr-muted', '--rhr-border',
    '--rhr-panel', '--rhr-input', '--rhr-btn-text', '--rhr-chip', '--rhr-trigger-bg', '--rhr-trigger-text',
    '--rhr-overlay', '--rhr-radius', '--rhr-fs', '--rhr-sidebar', '--rhr-gap', '--rhr-cols', '--rhr-shadow', '--rhr-shadow-lg'];

  var PRODUCT_SELECTORS = [
    '.elementor-widget-wc-archive-products',
    '.elementor-widget-woocommerce-archive-products',
    '.elementor-widget-loop-grid',
    '.elementor-widget-woocommerce-products',
    '.wc-block-product-template',
    'ul.products'
  ];

  /* ---------------- helpers ---------------- */
  function $(s, c) { return (c || document).querySelector(s); }
  function $$(s, c) { return Array.prototype.slice.call((c || document).querySelectorAll(s)); }
  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>'"]/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#039;', '"': '&quot;' }[c];
    });
  }
  function debounce(fn, ms) {
    var t;
    return function () { var a = arguments, c = this; clearTimeout(t); t = setTimeout(function () { fn.apply(c, a); }, ms); };
  }
  function raf2(fn) { requestAnimationFrame(function () { requestAnimationFrame(fn); }); }
  function isEditor() { return document.body.classList.contains('elementor-editor-active'); }
  function visible(el) { return !!(el && (el.offsetWidth || el.offsetHeight || el.getClientRects().length)); }
  function cleanClasses(cls) {
    return String(cls || '').split(/\s+/).filter(function (c) {
      return c && !/^(elementor-hidden-|elementor-invisible$|animated|e-con|e-flex|e-grid|e-parent|e-child|elementor-sticky)/.test(c);
    }).join(' ');
  }
  function stripPaging(url) {
    url.pathname = url.pathname.replace(/\/page\/\d+\/?$/, '/');
    url.searchParams.delete('paged');
    url.searchParams.delete('product-page');
    return url;
  }
  function findProducts() {
    var sels = (G.productsSelector ? [G.productsSelector] : []).concat(PRODUCT_SELECTORS);
    for (var i = 0; i < sels.length; i++) {
      var list;
      try { list = $$(sels[i]); } catch (e) { continue; }
      for (var j = 0; j < list.length; j++) {
        if (!list[j].closest('.rhr-wpf-wrap, .rhr-host')) return { el: list[j], sel: sels[i] };
      }
    }
    return null;
  }
  function copyVars(from, to) {
    var cs = getComputedStyle(from);
    VARS.forEach(function (n) { var v = cs.getPropertyValue(n).trim(); if (v) to.style.setProperty(n, v); });
  }

  /**
   * Elements that leave the widget (drawer portal, mobile toolbar) are wrapped
   * in copies of the Elementor document/widget wrappers (display:contents), so
   * Elementor style controls ({{WRAPPER}} selectors) keep applying to them.
   */
  function scopeHost(root, extra) {
    var outer = document.createElement('div');
    outer.className = 'rhr-host ' + (extra || '');
    var host = outer;
    [root.closest('[data-elementor-id]'), root.closest('.elementor-element')].forEach(function (src) {
      if (!src) return;
      var d = document.createElement('div');
      d.className = cleanClasses(src.className);
      d.style.setProperty('display', 'contents', 'important');
      host.appendChild(d);
      host = d;
    });
    var scope = document.createElement('div');
    scope.className = 'rhr-scope ' + Array.prototype.filter.call(root.classList, function (c) { return /^rhr-preset-/.test(c); }).join(' ');
    copyVars(root, scope);
    host.appendChild(scope);
    return { outer: outer, scope: scope };
  }

  /* ---------------- shared mobile toolbar ---------------- */
  function syncOrdering() {
    if (!bar) return;
    var want = mq.matches && +G.moveOrdering && !bar.scope.hidden;
    if (want) {
      var ord = $$('.woocommerce-ordering').filter(function (o) { return !o.closest('.rhr-wpf-wrap') && !bar.scope.contains(o); })[0];
      if (ord) {
        if (bar.ordering && bar.scope.contains(bar.ordering)) bar.ordering.remove();
        if (bar.mark) bar.mark.remove();
        bar.mark = document.createComment('rhr-ordering');
        ord.parentNode.insertBefore(bar.mark, ord);
        bar.scope.appendChild(ord);
        bar.ordering = ord;
      }
    } else if (bar.ordering && bar.scope.contains(bar.ordering) && bar.mark && bar.mark.parentNode) {
      bar.mark.parentNode.insertBefore(bar.ordering, bar.mark);
      bar.mark.remove();
      bar.ordering = null; bar.mark = null;
    }
  }

  /* ---------------- instance ---------------- */
  function boot(root) {
    if (!root || root.getAttribute('data-rhr-ready')) return;
    root.setAttribute('data-rhr-ready', '1');

    var cfg = {};
    try { cfg = JSON.parse(root.getAttribute('data-rhr') || '{}'); } catch (e) { cfg = {}; }
    var panel = $('.rhr-filter-panel', root);
    var form = $('.rhr-filter-form', root);
    var trigger = $('.rhr-trigger', root);
    if (!panel || !form) return;

    var archive = cfg.mode === 'archive';
    var editor = !!cfg.editor || isEditor();
    var inst = { root: root, cfg: cfg, archive: archive, open: false, drawer: false };
    instances.push(inst);

    var panelMark = document.createComment('rhr-panel');
    panel.parentNode.insertBefore(panelMark, panel);
    var triggerMark = document.createComment('rhr-trigger');
    if (trigger) trigger.parentNode.insertBefore(triggerMark, trigger);

    var portal = null, portalOuter = null, floatHost = null, lastFocus = null, snapshot = null;
    var applyBtn = $('.rhr-apply', panel);

    /* ----- form state ----- */
    var price = $('.rhr-price', form);
    var P = null;
    if (price) {
      P = {
        min: +price.getAttribute('data-min') || 0,
        max: +price.getAttribute('data-max') || 0,
        rmin: $('.rhr-range-min', price), rmax: $('.rhr-range-max', price),
        nmin: $('[name="rhr_min_price"]', price), nmax: $('[name="rhr_max_price"]', price),
        fill: $('.rhr-range-fill', price)
      };
    }
    var search = $('[name="rhr_s"]', form);
    var suggest = $('.rhr-suggest', form);
    var searchClear = $('.rhr-search-clear', form);

    function priceFill() {
      if (!P || !P.rmin) return;
      var span = (P.max - P.min) || 1;
      var lo = Math.max(P.min, Math.min(+P.rmin.value, P.max));
      var hi = Math.max(P.min, Math.min(+P.rmax.value, P.max));
      if (P.fill) {
        P.fill.style.left = ((lo - P.min) / span * 100) + '%';
        P.fill.style.right = (100 - (hi - P.min) / span * 100) + '%';
      }
      P.rmin.style.zIndex = lo > P.max - span * 0.1 ? 5 : 3;
    }

    function priceValues() {
      if (!P) return { min: '', max: '' };
      var a = P.nmin.value === '' ? '' : Math.max(0, parseFloat(P.nmin.value));
      var b = P.nmax.value === '' ? '' : Math.max(0, parseFloat(P.nmax.value));
      if (a !== '' && a <= P.min) a = '';
      if (b !== '' && b >= P.max) b = '';
      if (a !== '' && b !== '' && a > b) { var t = a; a = b; b = t; }
      return { min: isNaN(a) ? '' : a, max: isNaN(b) ? '' : b };
    }

    /** Filter params as [key, value] pairs (only meaningful values). */
    function params() {
      var out = [];
      var fd = new FormData(form);
      fd.forEach(function (v, k) {
        if (k === 'rhr_min_price' || k === 'rhr_max_price' || v === '' || v == null) return;
        if (k === 'rhr_s') { v = String(v).trim(); if (!v) return; }
        out.push([k, v]);
      });
      var pv = priceValues();
      if (pv.min !== '') out.push(['rhr_min_price', pv.min]);
      if (pv.max !== '') out.push(['rhr_max_price', pv.max]);
      return out;
    }

    function archiveUrl() {
      var u = stripPaging(new URL(window.location.href));
      var drop = [];
      u.searchParams.forEach(function (v, k) { if (k.indexOf('rhr_') === 0) drop.push(k); });
      drop.forEach(function (k) { u.searchParams.delete(k); });
      params().forEach(function (p) { u.searchParams.append(p[0], p[1]); });
      u.hash = '';
      return u.toString();
    }

    function activeItems() {
      var items = [];
      if (search && search.value.trim()) {
        items.push({ label: (T.search || 'Search') + ': ' + search.value.trim(), clear: function () { search.value = ''; toggleClear(); } });
      }
      $$('input[type="checkbox"]:checked, input[type="radio"]:checked', form).forEach(function (i) {
        if (!i.value || !i.getAttribute('data-label')) return;
        items.push({
          label: i.getAttribute('data-label'), clear: function () {
            if (i.type === 'radio') { var any = $('input[name="' + i.name + '"][value=""]', form); if (any) any.checked = true; else i.checked = false; }
            else i.checked = false;
          }
        });
      });
      var pv = priceValues();
      if (pv.min !== '' || pv.max !== '') {
        var cur = G.currency || '';
        items.push({
          label: cur + (pv.min !== '' ? pv.min : P.min) + ' – ' + cur + (pv.max !== '' ? pv.max : P.max), clear: function () { resetPrice(); }
        });
      }
      return items;
    }

    function resetPrice() {
      if (!P) return;
      P.nmin.value = ''; P.nmax.value = '';
      if (P.rmin) { P.rmin.value = P.min; P.rmax.value = P.max; }
      priceFill();
    }

    function toggleClear() { if (searchClear && search) searchClear.hidden = !search.value; }

    function updateUI() {
      var items = activeItems();
      var n = items.length;
      $$('.rhr-filter-count').forEach(function (b) {
        if (b.closest('.rhr-wpf-wrap') === root || (trigger && trigger.contains(b))) { b.textContent = n; b.hidden = n === 0; }
      });
      $$('.rhr-reset-link', panel).forEach(function (b) { b.hidden = n === 0; });

      var box = $('.rhr-active', form);
      if (box) {
        var list = $('.rhr-active-list', box);
        list.innerHTML = '';
        items.forEach(function (it) {
          var b = document.createElement('button');
          b.type = 'button';
          b.className = 'rhr-active-chip';
          b.innerHTML = '<span>' + esc(it.label) + '</span><i aria-hidden="true">×</i>';
          b.setAttribute('aria-label', 'Remove ' + it.label);
          b.addEventListener('click', function () { it.clear(); changed(); });
          list.appendChild(b);
        });
        box.hidden = n === 0;
      }
      // Selected count next to each section title.
      $$('.rhr-sec', form).forEach(function (sec) {
        var meta = $('.rhr-sec-meta', sec);
        if (!meta) return;
        var c = $$('input[type="checkbox"]:checked', sec).length + $$('input[type="radio"]:checked:not([value=""])', sec).length;
        meta.textContent = c ? c : '';
        meta.hidden = !c;
      });
      toggleClear();
    }

    function serialize() {
      return $$('input, select', form).map(function (i) {
        return (i.type === 'checkbox' || i.type === 'radio') ? i.checked : i.value;
      });
    }
    function restore(state) {
      if (!state) return;
      $$('input, select', form).forEach(function (i, idx) {
        if (idx >= state.length) return;
        if (i.type === 'checkbox' || i.type === 'radio') i.checked = state[idx]; else i.value = state[idx];
      });
      priceFill(); updateUI();
    }

    /* ----- applying ----- */
    function run(opts) {
      opts = opts || {};
      snapshot = serialize();
      if (editor) return;
      if (archive) navigate(archiveUrl(), { scroll: opts.scroll });
      else loadGrid(1);
    }

    function changed() {
      updateUI();
      if (inst.drawer && inst.open && cfg.apply !== 'instant') {
        if (applyBtn) applyBtn.classList.add('is-pending');
        return;
      }
      run();
    }

    function resetAll() {
      $$('input', form).forEach(function (i) {
        if (i.type === 'checkbox') i.checked = false;
        else if (i.type === 'radio') i.checked = i.value === '';
        else if (i.type !== 'range') i.value = '';
      });
      resetPrice();
      hideSuggest();
      updateUI();
      run();
      if (inst.open) close(true);
    }

    /* ----- drawer ----- */
    function mountDrawer() {
      if (portal) return;
      var h = scopeHost(root, 'rhr-portal-host');
      portalOuter = h.outer;
      portal = h.scope;
      portal.classList.add('rhr-portal', 'rhr-side-' + (cfg.side || 'right'), 'rhr-no-anim');
      portal.setAttribute('data-for', root.id);
      var backdrop = document.createElement('div');
      backdrop.className = 'rhr-backdrop';
      backdrop.addEventListener('click', function () { close(); });
      portal.appendChild(backdrop);
      portal.appendChild(panel);
      panel.setAttribute('role', 'dialog');
      panel.setAttribute('aria-modal', 'true');
      panel.setAttribute('aria-hidden', 'true');
      panel.setAttribute('inert', '');
      document.body.appendChild(portalOuter);
      inst.drawer = true;
      // Transitions are enabled only after the first paint → no slide "flash".
      raf2(function () { if (portal) portal.classList.remove('rhr-no-anim'); });
    }

    function unmountDrawer() {
      if (!portal) return;
      close(true, true);
      panelMark.parentNode.insertBefore(panel, panelMark.nextSibling);
      ['role', 'aria-modal', 'aria-hidden', 'inert'].forEach(function (a) { panel.removeAttribute(a); });
      portalOuter.remove();
      portal = null; portalOuter = null; inst.drawer = false;
    }

    function open() {
      if (!portal) return;
      snapshot = serialize();
      lastFocus = document.activeElement;
      inst.open = true;
      panel.removeAttribute('inert');
      panel.setAttribute('aria-hidden', 'false');
      portal.classList.add('is-open');
      document.documentElement.classList.add('rhr-lock');
      if (trigger) trigger.setAttribute('aria-expanded', 'true');
      if (applyBtn) applyBtn.classList.remove('is-pending');
      setTimeout(function () { var c = $('.rhr-close', panel); if (c) try { c.focus({ preventScroll: true }); } catch (e) { c.focus(); } }, 60);
    }

    function close(keepState, silent) {
      if (!portal || !inst.open) return;
      if (!keepState && cfg.apply !== 'instant' && snapshot) restore(snapshot); // discard un-applied changes
      inst.open = false;
      hideSuggest();
      portal.classList.remove('is-open');
      panel.setAttribute('aria-hidden', 'true');
      panel.setAttribute('inert', '');
      if (!instances.some(function (i) { return i.open; })) document.documentElement.classList.remove('rhr-lock');
      if (trigger) trigger.setAttribute('aria-expanded', 'false');
      if (!silent && lastFocus && lastFocus.focus && document.contains(lastFocus)) {
        try { lastFocus.focus({ preventScroll: true }); } catch (e) { /* noop */ }
      }
    }
    inst.close = close;

    function restoreTrigger() {
      if (!trigger) return;
      if (triggerMark.parentNode && trigger.previousSibling !== triggerMark) {
        triggerMark.parentNode.insertBefore(trigger, triggerMark.nextSibling);
      }
      trigger.classList.remove('rhr-trigger-bar', 'rhr-trigger-float');
      if (floatHost) { floatHost.remove(); floatHost = null; }
    }

    function placeTrigger() {
      if (!trigger) return;
      var pos = cfg.trigger || 'auto';
      var primary = instances.filter(function (i) { return i.drawer; })[0] === inst;
      if (pos === 'auto') {
        var t = archive && primary ? findProducts() : null;
        if (t) {
          if (!bar) {
            var h = scopeHost(root, 'rhr-bar-host');
            h.scope.classList.add('rhr-bar');
            t.el.parentNode.insertBefore(h.outer, t.el);
            bar = { outer: h.outer, scope: h.scope, ordering: null, mark: null, owner: inst };
          }
          if (bar.owner === inst) {
            bar.scope.hidden = false;
            if (trigger.parentNode !== bar.scope) bar.scope.insertBefore(trigger, bar.scope.firstChild);
            trigger.classList.add('rhr-trigger-bar');
            syncOrdering();
            return;
          }
        }
        pos = visible(root) ? 'inline' : 'floating';
      }
      if (pos === 'inline' && !visible(root)) pos = 'floating';
      if (pos === 'floating') {
        if (!floatHost) {
          var f = scopeHost(root, 'rhr-float-host');
          f.scope.classList.add('rhr-float');
          floatHost = f.outer;
          document.body.appendChild(floatHost);
          f.scope.appendChild(trigger);
        }
        trigger.classList.add('rhr-trigger-float');
        return;
      }
      restoreTrigger();
    }

    function layout() {
      var mobile = mq.matches;
      root.classList.toggle('rhr-is-mobile', mobile);
      if (editor) { root.classList.add('rhr-editor'); return; }
      var wantDrawer = mobile ? cfg.mLayout !== 'inline' : cfg.dMode === 'drawer';
      if (wantDrawer) { mountDrawer(); placeTrigger(); }
      else {
        unmountDrawer();
        restoreTrigger();
        if (bar && bar.owner === inst) { bar.scope.hidden = true; syncOrdering(); }
      }
      if (!mobile) root.classList.remove('rhr-inline-open');
    }
    inst.layout = layout;

    /* ----- search suggestions ----- */
    var sugCtl = null, sugIndex = -1;
    function hideSuggest() {
      if (sugCtl && sugCtl.abort) { sugCtl.abort(); sugCtl = null; }
      if (suggest) { suggest.hidden = true; suggest.innerHTML = ''; sugIndex = -1; }
    }
    function highlight(text, term) {
      var safe = esc(text);
      var t = esc(term).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      if (!t) return safe;
      try { return safe.replace(new RegExp('(' + t + ')', 'ig'), '<mark>$1</mark>'); } catch (e) { return safe; }
    }
    var fetchSuggest = debounce(function (term) {
      if (!suggest || !G.ajax || document.activeElement !== search) return;
      if (term.length < (+G.searchMin || 2)) { hideSuggest(); return; }
      if (sugCtl && sugCtl.abort) sugCtl.abort();
      sugCtl = window.AbortController ? new AbortController() : null;
      suggest.hidden = false;
      suggest.innerHTML = '<div class="rhr-sg-status"><span class="rhr-spin"></span>' + esc(T.searching || 'Searching…') + '</div>';
      var url = G.ajax + (G.ajax.indexOf('?') > -1 ? '&' : '?') + 'action=rhr_wpf_search&term=' + encodeURIComponent(term) + (cfg.cat ? '&cat=' + cfg.cat : '');
      fetch(url, { credentials: 'same-origin', signal: sugCtl ? sugCtl.signal : undefined })
        .then(function (r) { return r.json(); })
        .then(function (res) {
          if (!search || search.value.trim() !== term || document.activeElement !== search) { hideSuggest(); return; }
          var items = (res && res.data && res.data.items) || [];
          var html = '';
          items.forEach(function (it) {
            html += '<a class="rhr-sg-item" role="option" href="' + esc(it.url) + '">' +
              (it.image ? '<img src="' + esc(it.image) + '" alt="" loading="lazy">' : '<span class="rhr-sg-noimg"></span>') +
              '<span class="rhr-sg-text"><span class="rhr-sg-title">' + highlight(it.title, term) + '</span>' +
              '<span class="rhr-sg-price">' + (it.price || '') + '</span>' +
              (it.stock ? '<span class="rhr-sg-stock">' + esc(it.stock) + '</span>' : '') + '</span></a>';
          });
          if (!items.length) html = '<div class="rhr-sg-status">' + esc(T.noResults || 'No products found.') + '</div>';
          html += '<button type="button" class="rhr-sg-all">' + esc(T.viewAll || 'See all results for') + ' “' + esc(term) + '”' + (res.data && res.data.total > items.length ? ' <em>' + res.data.total + '</em>' : '') + '</button>';
          suggest.innerHTML = html;
          suggest.hidden = false;
          sugIndex = -1;
        })
        .catch(function (e) { if (!e || e.name !== 'AbortError') hideSuggest(); });
    }, 230);

    function submitSearch() {
      hideSuggest();
      if (search) search.blur();
      updateUI();
      run({ scroll: true });
      if (inst.open) close(true);
    }

    if (search) {
      search.addEventListener('input', function () { toggleClear(); fetchSuggest(search.value.trim()); });
      search.addEventListener('focus', function () { if (search.value.trim().length >= (+G.searchMin || 2) && suggest && !suggest.innerHTML) fetchSuggest(search.value.trim()); });
      search.addEventListener('keydown', function (e) {
        var opts = suggest ? $$('.rhr-sg-item, .rhr-sg-all', suggest) : [];
        if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
          if (!opts.length) return;
          e.preventDefault();
          sugIndex = (sugIndex + (e.key === 'ArrowDown' ? 1 : -1) + opts.length) % opts.length;
          opts.forEach(function (o, i) { o.classList.toggle('is-active', i === sugIndex); });
        } else if (e.key === 'Enter') {
          e.preventDefault();
          var act = opts[sugIndex];
          if (act && act.tagName === 'A') { window.location.href = act.href; return; }
          submitSearch();
        } else if (e.key === 'Escape') {
          if (suggest && !suggest.hidden) { e.stopPropagation(); hideSuggest(); }
        }
      });
    }
    form.addEventListener('submit', function (e) { e.preventDefault(); submitSearch(); });

    /* ----- price ----- */
    if (P && P.rmin && P.rmax) {
      var step = +P.rmin.step || 1;
      var onRange = function (src) {
        var lo = +P.rmin.value, hi = +P.rmax.value;
        if (lo > hi - step) { if (src === P.rmin) P.rmin.value = hi; else P.rmax.value = lo; }
        P.nmin.value = +P.rmin.value <= P.min ? '' : P.rmin.value;
        P.nmax.value = +P.rmax.value >= P.max ? '' : P.rmax.value;
        priceFill();
      };
      P.rmin.addEventListener('input', function () { onRange(P.rmin); });
      P.rmax.addEventListener('input', function () { onRange(P.rmax); });
      [P.nmin, P.nmax].forEach(function (n) {
        n.addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); n.blur(); } });
      });
      priceFill();
    }

    /* ----- change handling ----- */
    form.addEventListener('change', function (e) {
      var t = e.target;
      if (!t || t.name === 'rhr_s') return;
      if (P && (t === P.nmin || t === P.nmax)) {
        var v = t.value === '' ? '' : parseFloat(t.value);
        if (v !== '' && !isNaN(v)) {
          v = Math.max(P.min, Math.min(P.max, v));
          t.value = (t === P.nmin && v <= P.min) || (t === P.nmax && v >= P.max) ? '' : v;
        } else t.value = '';
        if (P.rmin) { P.rmin.value = P.nmin.value === '' ? P.min : P.nmin.value; P.rmax.value = P.nmax.value === '' ? P.max : P.nmax.value; }
        priceFill();
      }
      changed();
    });

    /* ----- clicks inside the panel ----- */
    panel.addEventListener('click', function (e) {
      var t = e.target;
      var el;
      if ((el = t.closest('.rhr-close'))) { close(); return; }
      if ((el = t.closest('.rhr-apply'))) { if (el.classList.contains('is-pending') || cfg.apply === 'instant') { el.classList.remove('is-pending'); if (cfg.apply !== 'instant') run({ scroll: true }); } close(true); return; }
      if ((el = t.closest('.rhr-reset'))) { resetAll(); return; }
      if ((el = t.closest('.rhr-search-clear'))) {
        search.value = ''; hideSuggest(); toggleClear();
        var had = new URL(window.location.href).searchParams.get('rhr_s');
        if (had) changed(); else search.focus();
        return;
      }
      if ((el = t.closest('.rhr-sg-all'))) { submitSearch(); return; }
      if ((el = t.closest('.rhr-sec-head')) && !el.classList.contains('is-static')) {
        var sec = el.closest('.rhr-sec');
        var collapsed = sec.classList.toggle('is-collapsed');
        el.setAttribute('aria-expanded', collapsed ? 'false' : 'true');
        return;
      }
      if ((el = t.closest('.rhr-tree-toggle'))) {
        var li = el.closest('.rhr-term');
        var isOpen = li.classList.toggle('is-open');
        el.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
        return;
      }
      if ((el = t.closest('.rhr-more'))) {
        var body = el.closest('.rhr-sec-body');
        var more = body.classList.toggle('show-all');
        el.innerHTML = esc(more ? el.getAttribute('data-less') : el.getAttribute('data-more'));
      }
    });

    // Swipe the drawer closed.
    (function () {
      var x0 = null, y0 = null;
      panel.addEventListener('touchstart', function (e) { if (!inst.open) return; x0 = e.touches[0].clientX; y0 = e.touches[0].clientY; }, { passive: true });
      panel.addEventListener('touchend', function (e) {
        if (x0 === null || !inst.open) return;
        var dx = e.changedTouches[0].clientX - x0, dy = e.changedTouches[0].clientY - y0;
        var side = cfg.side || 'right';
        if ((side === 'right' && dx > 70 && Math.abs(dy) < 50) || (side === 'left' && dx < -70 && Math.abs(dy) < 50) ||
          (side === 'bottom' && dy > 90 && Math.abs(dx) < 60 && panel.scrollTop <= 0)) close();
        x0 = y0 = null;
      }, { passive: true });
    })();

    if (trigger) {
      trigger.addEventListener('click', function () {
        if (inst.drawer) { if (inst.open) close(); else open(); return; }
        var isOpen = root.classList.toggle('rhr-inline-open');
        trigger.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
      });
    }

    document.addEventListener('click', function (e) {
      if (suggest && !suggest.hidden && !e.target.closest('.rhr-search')) hideSuggest();
    });

    /* ----- color swatches ----- */
    $$('.rhr-dot[data-color]', form).forEach(function (d) {
      var c = d.getAttribute('data-color');
      if (c && window.CSS && CSS.supports && CSS.supports('color', c)) d.style.background = c;
      else d.closest('.rhr-chip').classList.add('rhr-no-color');
    });

    /* ----- standalone grid mode ----- */
    var area = $('.rhr-products-area', root);
    var gridCtl = null;
    function loadGrid(page) {
      if (!area) return;
      var grid = $('.rhr-products-grid', area), count = $('.rhr-results-count', area), pages = $('.rhr-pagination', area), sort = $('.rhr-sort', area);
      var qs = new URLSearchParams();
      params().forEach(function (p) { qs.append(p[0], p[1]); });
      if (sort && sort.value && sort.value !== cfg.orderby) qs.set('orderby', sort.value);
      var body = new URLSearchParams();
      body.set('action', 'rhr_wpf_grid');
      body.set('query', qs.toString());
      body.set('paged', page || 1);
      body.set('per_page', (cfg.grid && cfg.grid.per_page) || 12);
      body.set('columns', (cfg.grid && cfg.grid.columns) || 3);
      body.set('category', (cfg.grid && cfg.grid.category) || '');
      if (gridCtl && gridCtl.abort) gridCtl.abort();
      gridCtl = window.AbortController ? new AbortController() : null;
      area.classList.add('rhr-is-loading');
      fetch(G.ajax, { method: 'POST', credentials: 'same-origin', body: body, signal: gridCtl ? gridCtl.signal : undefined })
        .then(function (r) { return r.json(); })
        .then(function (res) {
          if (!res || !res.success) throw new Error('bad');
          grid.innerHTML = res.data.html;
          if (count) count.textContent = res.data.count;
          if (pages) pages.innerHTML = res.data.pagination;
          // Keep the URL shareable.
          var u = stripPaging(new URL(window.location.href));
          var drop = [];
          u.searchParams.forEach(function (v, k) { if (k.indexOf('rhr_') === 0 || k === 'orderby') drop.push(k); });
          drop.forEach(function (k) { u.searchParams.delete(k); });
          qs.forEach(function (v, k) { u.searchParams.append(k, v); });
          if (window.history && history.replaceState) history.replaceState(history.state, '', u.toString());
          var top = area.getBoundingClientRect().top;
          if (page > 1 || top < 0) window.scrollTo({ top: window.pageYOffset + top - 100, behavior: 'smooth' });
          if (window.jQuery) window.jQuery(document.body).trigger('rhr_wpf_updated', [area]);
        })
        .catch(function (e) { if (!e || e.name !== 'AbortError') grid.innerHTML = '<p class="woocommerce-info">' + esc(T.error || 'Error') + '</p>'; })
        .then(function () { area.classList.remove('rhr-is-loading'); });
    }
    if (area) {
      area.addEventListener('click', function (e) {
        var b = e.target.closest('.rhr-page[data-page]');
        if (b) { e.preventDefault(); loadGrid(+b.getAttribute('data-page')); }
      });
      var sortSel = $('.rhr-sort', area);
      if (sortSel) sortSel.addEventListener('change', function () { loadGrid(1); });
    }

    updateUI();
    layout();
    bindGlobals();
  }

  /* ---------------- archive AJAX navigation ---------------- */
  function primaryArchive() { return instances.filter(function (i) { return i.archive; })[0]; }

  function navigate(url, opts) {
    opts = opts || {};
    var t = findProducts();
    if (!+G.ajaxArchive || !t || !window.fetch || !window.DOMParser || !window.history || !history.pushState) {
      window.location.assign(url);
      return;
    }
    if (navCtl && navCtl.abort) navCtl.abort();
    navCtl = window.AbortController ? new AbortController() : null;
    var inst = primaryArchive();
    if (inst) {
      var accent = getComputedStyle(inst.root).getPropertyValue('--rhr-accent').trim();
      if (accent) t.el.style.setProperty('--rhr-accent', accent);
    }
    t.el.classList.add('rhr-loading');
    document.documentElement.classList.add('rhr-busy');

    fetch(url, { credentials: 'same-origin', signal: navCtl ? navCtl.signal : undefined })
      .then(function (r) { if (!r.ok && r.status !== 404) throw new Error('http'); return r.text(); })
      .then(function (html) {
        var doc = new DOMParser().parseFromString(html, 'text/html');
        var id = t.el.getAttribute('data-id');
        var fresh = id ? doc.querySelector('[data-id="' + id + '"]') : null;
        if (!fresh && !id) fresh = doc.querySelector(t.sel);
        if (!fresh && t.sel === 'ul.products') fresh = doc.querySelector('.woocommerce-no-products-found, .woocommerce-info');
        if (!fresh) throw new Error('nomatch');

        // Result count / pagination that live outside the products container (classic themes).
        ['.woocommerce-result-count', 'nav.woocommerce-pagination'].forEach(function (sel) {
          var old = $$(sel).filter(function (el) { return !t.el.contains(el); })[0];
          if (!old) return;
          var nw = doc.querySelector(sel);
          if (nw && !(fresh.contains && fresh.contains(nw))) old.replaceWith(document.importNode(nw, true));
          else if (!nw) old.innerHTML = '';
        });

        var node = document.importNode(fresh, true);
        t.el.replaceWith(node);
        document.title = doc.title || document.title;
        history.pushState({ rhr: 1 }, '', url);

        if (bar) syncOrdering();
        afterReplace(node);

        var top = node.getBoundingClientRect().top;
        if (opts.scroll !== false && (top < 0 || top > window.innerHeight * 0.6)) {
          var offset = (bar && visible(bar.scope)) ? bar.scope.getBoundingClientRect().top : top;
          window.scrollTo({ top: Math.max(0, window.pageYOffset + Math.min(top, offset) - 90), behavior: 'smooth' });
        }
      })
      .catch(function (e) {
        if (e && e.name === 'AbortError') return;
        window.location.assign(url);
      })
      .then(function () {
        var cur = findProducts();
        if (cur) cur.el.classList.remove('rhr-loading');
        document.documentElement.classList.remove('rhr-busy');
      });
  }

  function afterReplace(node) {
    var jq = window.jQuery;
    if (jq) {
      if (window.elementorFrontend && elementorFrontend.elementsHandler && elementorFrontend.elementsHandler.runReadyTrigger) {
        try {
          elementorFrontend.elementsHandler.runReadyTrigger(jq(node));
          jq(node).find('.elementor-element').each(function () { elementorFrontend.elementsHandler.runReadyTrigger(jq(this)); });
        } catch (e) { /* noop */ }
      }
      jq(document.body).trigger('rhr_wpf_updated', [node]);
      jq(document.body).trigger('post-load'); // lazy-load / Jetpack style listeners
    }
    try { document.dispatchEvent(new CustomEvent('rhr_wpf_updated', { detail: { node: node } })); } catch (e) { /* noop */ }
    window.dispatchEvent(new Event('resize'));
    window.dispatchEvent(new Event('scroll'));
  }

  function bindGlobals() {
    if (globalsBound) return;
    globalsBound = true;

    if (window.history && history.replaceState && !(history.state && history.state.rhr)) {
      try { history.replaceState({ rhr: 1 }, '', window.location.href); } catch (e) { /* noop */ }
    }
    window.addEventListener('popstate', function (e) { if (e.state && e.state.rhr && primaryArchive()) window.location.reload(); });

    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') instances.forEach(function (i) { if (i.open && i.close) i.close(); });
    });

    var onMQ = function () { instances.forEach(function (i) { i.layout(); }); };
    if (mq.addEventListener) mq.addEventListener('change', onMQ); else if (mq.addListener) mq.addListener(onMQ);

    // AJAX pagination for the archive products widget.
    document.addEventListener('click', function (e) {
      if (!+G.ajaxArchive || !primaryArchive() || e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
      var a = e.target.closest && e.target.closest('.woocommerce-pagination a, .elementor-pagination a, nav.pagination a, a.page-numbers');
      if (!a || !a.href || a.target === '_blank') return;
      var t = findProducts();
      if (!t || !(t.el.contains(a) || $$('nav.woocommerce-pagination').some(function (n) { return n.contains(a); }))) return;
      if (a.hostname !== window.location.hostname) return;
      e.preventDefault();
      navigate(a.href);
    });

    // WooCommerce "Sort by" select → AJAX as well (works even after it was moved/replaced).
    document.addEventListener('change', function (e) {
      if (!+G.ajaxArchive || !primaryArchive()) return;
      var sel = e.target;
      if (!sel || !sel.matches || !sel.matches('.woocommerce-ordering select')) return;
      e.stopPropagation();
      var u = stripPaging(new URL(window.location.href));
      u.searchParams.set(sel.name || 'orderby', sel.value);
      navigate(u.toString());
    }, true);
    document.addEventListener('submit', function (e) {
      if (+G.ajaxArchive && primaryArchive() && e.target && e.target.matches && e.target.matches('.woocommerce-ordering')) e.preventDefault();
    }, true);
  }

  /* ---------------- start ---------------- */
  function bootAll(ctx) { $$('.rhr-wpf-wrap', ctx || document).forEach(boot); }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { bootAll(); });
  else bootAll();

  // Elementor editor / preview: (re)initialise when the widget re-renders.
  var hooked = false;
  function hookElementor() {
    if (hooked || !window.elementorFrontend || !elementorFrontend.hooks) return;
    hooked = true;
    elementorFrontend.hooks.addAction('frontend/element_ready/rhr-product-filter.default', function ($scope) {
      bootAll($scope && $scope[0] ? $scope[0] : $scope);
    });
  }
  if (window.jQuery) window.jQuery(window).on('elementor/frontend/init', hookElementor);
  window.addEventListener('elementor/frontend/init', hookElementor);
  hookElementor();

  window.RHRWPFBoot = bootAll;
})();
