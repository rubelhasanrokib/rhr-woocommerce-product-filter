<?php
/**
 * Plugin Name:       RHR WooCommerce Product Filter
 * Plugin URI:        https://rubelhasanrokib.com/
 * Description:       Premium responsive WooCommerce product filter. Works with the real WooCommerce / Elementor Pro archive query, AJAX results without page reload, live product search, hierarchical categories, attribute chips & color swatches, price slider, smooth mobile drawer, native Elementor widget and full color control from the dashboard.
 * Version:           2.0.1
 * Author:            Rubel Hasan Rokib
 * Author URI:        https://rubelhasanrokib.com/
 * Text Domain:       rhr-woocommerce-product-filter
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Requires Plugins:  woocommerce
 * WC requires at least: 6.0
 * WC tested up to:   10.2
 * Elementor tested up to: 3.32
 * License:           GPLv2 or later
 */

if (!defined('ABSPATH')) exit;

define('RHR_WPF_VERSION', '2.0.1');
define('RHR_WPF_FILE', __FILE__);
define('RHR_WPF_URL', plugin_dir_url(__FILE__));
define('RHR_WPF_PATH', plugin_dir_path(__FILE__));

require_once RHR_WPF_PATH . 'includes/class-rhr-wpf.php';
require_once RHR_WPF_PATH . 'includes/class-rhr-wpf-query.php';
require_once RHR_WPF_PATH . 'includes/class-rhr-wpf-render.php';
require_once RHR_WPF_PATH . 'includes/class-rhr-wpf-admin.php';
require_once RHR_WPF_PATH . 'includes/class-rhr-wpf-elementor.php';

register_activation_hook(__FILE__, array('RHR_WPF', 'activate'));
add_action('plugins_loaded', array('RHR_WPF', 'init'));

// Declare compatibility with WooCommerce HPOS (the filter only reads products).
add_action('before_woocommerce_init', function () {
    if (class_exists('\Automattic\WooCommerce\Utilities\FeaturesUtil')) {
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('custom_order_tables', __FILE__, true);
    }
});
