<?php
if (!defined('WP_UNINSTALL_PLUGIN')) exit;
foreach ((array) get_option('rhr_wpf_bounds_keys', array()) as $key) delete_transient($key);
delete_option('rhr_wpf_bounds_keys');
delete_option('rhr_wpf_settings');
delete_option('rhr_wpf_db_version');
